<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta name="description" content="Various links" />
	
	<meta name="keywords" content="bitcoin, forum, bitcoin forum, bitcointalk" />
	<script language="JavaScript" type="text/javascript" src="https://bitcointalk.org/Themes/default/script.js"></script>
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://bitcointalk.org/Themes/custom1";
		var smf_images_url = "https://bitcointalk.org/Themes/custom1/images";
		var smf_scripturl = "https://bitcointalk.org/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "ISO-8859-1";
	// ]]></script>
	<title>Various links</title><!--a74d8872e7b40c253b5b162b69fe049accb94ae89f1cfeb9-->
	<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/custom1/style.css" />
	 <!--[if !IE]> -->
	 <link rel="stylesheet" type="text/css" media="only screen and (min-device-width: 320px) and (max-device-width: 650px)" href="https://bitcointalk.org/Themes/custom1/mobile.css" />
	 <!-- <![endif]-->
	<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/default/print.css" media="print" /><style type="text/css">
.ZutHAQQfTaAbqhCcZAqFHA > td {background-color: #E5E5E8; text-align:center;}
.ZutHAQQfTaAbqhCcZAqFHA > td > table {margin-top:-5px}
.ZutHAQQfTaAbqhCcZAqFHA .hjCWXCLvScQaDYhLfJaRdg {display:inline-block;max-width:100%; min-width:100%; max-height:47px; overflow:hidden}
.ZutHAQQfTaAbqhCcZAqFHA table,.ZutHAQQfTaAbqhCcZAqFHA tbody,.ZutHAQQfTaAbqhCcZAqFHA tr,.ZutHAQQfTaAbqhCcZAqFHA td {display:inline-block;max-width:100%; min-width:100%; overflow:hidden}
.ZutHAQQfTaAbqhCcZAqFHA .hjCWXCLvScQaDYhLfJaRdg table,.ZutHAQQfTaAbqhCcZAqFHA .hjCWXCLvScQaDYhLfJaRdg tbody,.ZutHAQQfTaAbqhCcZAqFHA .hjCWXCLvScQaDYhLfJaRdg tr,.ZutHAQQfTaAbqhCcZAqFHA .hjCWXCLvScQaDYhLfJaRdg td {display:initial; max-width:none;min-width:none;overflow:visible}
.XnLRKdpbygKZwEaoyydfmA {display:none !important}
.BddqghZNqfJygPoPWXWjWg {display:none}
.BJFZuSyMAxGlsLnHNJkYGQ {padding: 1px 1px 0 1px;}
.cwafQEyYmIafOdaIGbAZgA{color:#699C62; font-weight:bold; font-size:18px}
.cwafQEyYmIafOdaIGbAZgA:link{color:#699C62; font-weight:bold; font-size:18px}
.cwafQEyYmIafOdaIGbAZgA:visited{color:#699C62; font-weight:bold; font-size:18px}
.bjAgbOUadGRKibrXuBcxQA{color:#00F30C;font-size:15px;font-weight:bold}
.bjAgbOUadGRKibrXuBcxQA:link{color:#00F30C;font-size:15px;font-weight:bold}
.bjAgbOUadGRKibrXuBcxQA:visited{color:#00F30C;font-size:15px;font-weight:bold}
.zmaLDgKSRafofNideYgKwQ{font-size:x-small}

.tirbnNJEpfIStiuIxhiOIA:link {font-size:22px;font-weight:bold;color:orange}
.tirbnNJEpfIStiuIxhiOIA:active {font-size:22px;font-weight:bold;color:orange}
.tirbnNJEpfIStiuIxhiOIA:visited {font-size:22px;font-weight:bold;color:orange}
.tirbnNJEpfIStiuIxhiOIA:hover {text-decoration:none !important;color:red}
.yEcDeqJxglHYZcUdfhUVig:link {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.yEcDeqJxglHYZcUdfhUVig:active {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.yEcDeqJxglHYZcUdfhUVig:visited {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.yEcDeqJxglHYZcUdfhUVig:hover {text-decoration:none !important;color:white;background-color:rgb(181,204,222)}
.yEcDeqJxglHYZcUdfhUVig {display:inline-block;margin: 3px;0;3px;0}
.obokBGbRVjjUYegyiSaKGg:hover {text-decoration:none !important;}
.obokBGbRVjjUYegyiSaKGg {font-size:22px;font-weight:bold;}
.cjagwyNexiudswhnWcLjPg {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .cjagwyNexiudswhnWcLjPg button {     border: none;     background: #8EE000;     color: #fff;     outline: none;     font-size: 1em;     padding: 0.5em 1.2em;     margin-left: 0.3em;     border-radius: 2em;     text-transform: uppercase;     font-weight: 600;     pointer-events: none;   }    .cjagwyNexiudswhnWcLjPg:hover .qnRdPYmkhyfjKNahRExQcA span {   display: none; }  .cjagwyNexiudswhnWcLjPg:hover .qnRdPYmkhyfjKNahRExQcA span:nth-child(2) {   display: block; }  .qnRdPYmkhyfjKNahRExQcA {   display: flex;   align-items: center; }    .qnRdPYmkhyfjKNahRExQcA span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .jMTKEAHGbixluFghRbPHdA {   display: inline-block; }  .qnRdPYmkhyfjKNahRExQcA span:nth-child(2) {   display: none; }  .bldCRLDkylzdhrQoyCyGjA {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .bldCRLDkylzdhrQoyCyGjA:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .bldCRLDkylzdhrQoyCyGjA > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .cjagwyNexiudswhnWcLjPg button {     display: none;   }   .qnRdPYmkhyfjKNahRExQcA {     margin-left: 1em;   } }   @media (max-width: 550px) {   .bldCRLDkylzdhrQoyCyGjA span span {     display: none;   } }  @media (max-width: 465px) {   .bldCRLDkylzdhrQoyCyGjA {     display: none;   }   .cjagwyNexiudswhnWcLjPg {     justify-content: center;   } }
.gciVcbrNqdrUZjbjjtAVjg {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .gciVcbrNqdrUZjbjjtAVjg button {     border: none;     background: #8EE000;     color: #fff;     outline: none;     font-size: 1em;     padding: 0.5em 1.2em;     margin-left: 0.4em;     border-radius: 2em;     text-transform: uppercase;     font-weight: 600; cursor:pointer; transition: all 0.3s;   } button:hover{transform: scale(1.05);}    .asfZsvaheMawJtnRfDPSMg:hover span{   display: none; }  .asfZsvaheMawJtnRfDPSMg:hover span:nth-child(2) {   display: block; }  .asfZsvaheMawJtnRfDPSMg {   display: flex;   align-items: center; color:#fff}    .asfZsvaheMawJtnRfDPSMg span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .lUVcWLthnotmtNsaIcAnaA {   display: inline-block; }  .asfZsvaheMawJtnRfDPSMg span:nth-child(2) {   display: none; }  .OHRaVordhhrPAufShymeiA {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .OHRaVordhhrPAufShymeiA:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .OHRaVordhhrPAufShymeiA > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .gciVcbrNqdrUZjbjjtAVjg button {     display: none;   }   .asfZsvaheMawJtnRfDPSMg {     margin-left: 1em;   } }   @media (max-width: 550px) {   .OHRaVordhhrPAufShymeiA span span {     display: none;   } }  @media (max-width: 465px) {   .OHRaVordhhrPAufShymeiA {     display: none;   }   .gciVcbrNqdrUZjbjjtAVjg {     justify-content: center;   } }
.cjagwyNexiudswhnWcLjPg {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .cjagwyNexiudswhnWcLjPg button {   border: none;   background: #8EE000;   color: #fff;   outline: none;   font-size: 1em;   padding: 0.5em 1.2em;   margin-left: 0.4em;   border-radius: 2em;   text-transform: uppercase;   font-weight: 600;   cursor: pointer;   transition: all 0.3s; }  button:hover {   transform: scale(1.05); }  .qnRdPYmkhyfjKNahRExQcA:hover span {   display: none; }  .qnRdPYmkhyfjKNahRExQcA:hover span:nth-child(2) {   display: block; }  .qnRdPYmkhyfjKNahRExQcA {   display: flex;   align-items: center;   color: #fff; }    .qnRdPYmkhyfjKNahRExQcA span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .jMTKEAHGbixluFghRbPHdA {   display: inline-block; }  .qnRdPYmkhyfjKNahRExQcA span:nth-child(2) {   display: none; }  .bldCRLDkylzdhrQoyCyGjA {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .bldCRLDkylzdhrQoyCyGjA:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .bldCRLDkylzdhrQoyCyGjA > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .cjagwyNexiudswhnWcLjPg button {     display: none;   }   .qnRdPYmkhyfjKNahRExQcA {     margin-left: 1em;   } }   @media (max-width: 550px) {   .bldCRLDkylzdhrQoyCyGjA span span {     display: none;   } }  @media (max-width: 465px) {   .bldCRLDkylzdhrQoyCyGjA {     display: none;   }   .cjagwyNexiudswhnWcLjPg {     justify-content: center;   } }
.gciVcbrNqdrUZjbjjtAVjg {   width: 900px;   height: 44px;   max-width: 100%;   background: #fff;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .gciVcbrNqdrUZjbjjtAVjg button {   border: none;   background: #8EE000;   color: #fff;   outline: none;   font-size: 1em;   padding: 0.5em 1.2em;   margin-left: 0.4em;   border-radius: 2em;   text-transform: uppercase;   font-weight: 600;   cursor: pointer;   transition: all 0.3s; }  button:hover {   transform: scale(1.05); }  .asfZsvaheMawJtnRfDPSMg:hover span {   display: none; }  .asfZsvaheMawJtnRfDPSMg:hover span:nth-child(2) {   display: block; }  .asfZsvaheMawJtnRfDPSMg {   display: flex;   align-items: center;   color: #5CB9F7; }    .asfZsvaheMawJtnRfDPSMg span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .lUVcWLthnotmtNsaIcAnaA {   display: inline-block; }  .asfZsvaheMawJtnRfDPSMg span:nth-child(2) {   display: none; }  .OHRaVordhhrPAufShymeiA {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .OHRaVordhhrPAufShymeiA:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .OHRaVordhhrPAufShymeiA > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .gciVcbrNqdrUZjbjjtAVjg button {     display: none;   }   .asfZsvaheMawJtnRfDPSMg {     margin-left: 1em;   } }   @media (max-width: 550px) {   .OHRaVordhhrPAufShymeiA span span {     display: none;   } }  @media (max-width: 465px) {   .OHRaVordhhrPAufShymeiA {     display: none;   }   .gciVcbrNqdrUZjbjjtAVjg {     justify-content: center;   } }
.aCghKjvYpWzCgAaWCcTKTw {   width: 900px;   height: 44px;   margin: 0 auto;   background: #fff;   max-width: 100%;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   color: #000 !important;   font-family: arial, sans-serif;   overflow: hidden; } .aCghKjvYpWzCgAaWCcTKTw:hover {   color: #fff;   background: #715AD0; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg span:nth-child(1) {   display: none; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg span:nth-child(2) {   display: block; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGhngTKEZZuFUAhYdfesDg span:nth-child(1) {   display: none;   color: #000; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGhngTKEZZuFUAhYdfesDg span:nth-child(2) {   display: block;   color: #000; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg {   background: #fff;   color: #000; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGhngTKEZZuFUAhYdfesDg {   background: #fff;   color: #000; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg:after {   background: #715AD0; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg:before {   background: #715AD0; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGPMFMobfmgrQaeXkFpafg span {   color: #000; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGhngTKEZZuFUAhYdfesDg:after {   background: #715AD0; } .aCghKjvYpWzCgAaWCcTKTw:hover .nGhngTKEZZuFUAhYdfesDg:before {   background: #715AD0; } .aCghKjvYpWzCgAaWCcTKTw:hover .xUgLfhdIIUpqfdDwduRmhg {   color: #fff; } .aCghKjvYpWzCgAaWCcTKTw:hover .xUgLfhdIIUpqfdDwduRmhg:before {   background: #fff; } .aCghKjvYpWzCgAaWCcTKTw:hover .xUgLfhdIIUpqfdDwduRmhg:after {   background: #fff; } .aCghKjvYpWzCgAaWCcTKTw .xUgLfhdIIUpqfdDwduRmhg {   display: flex;   height: 32px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   position: relative;   z-index: 2;   font-size: 18px;   color: #000;   width: 160px; } .aCghKjvYpWzCgAaWCcTKTw .xUgLfhdIIUpqfdDwduRmhg:after{   position: absolute;   right: 98%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .aCghKjvYpWzCgAaWCcTKTw .xUgLfhdIIUpqfdDwduRmhg:before{   position: absolute;   right: 2%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .aCghKjvYpWzCgAaWCcTKTw .xUgLfhdIIUpqfdDwduRmhg span {   font-size: 26px;   font-family: Existence;   font-weight: 600; } .aCghKjvYpWzCgAaWCcTKTw .xUgLfhdIIUpqfdDwduRmhg span:hover {   color: #fff;   text-decoration: none; } .aCghKjvYpWzCgAaWCcTKTw .nGPMFMobfmgrQaeXkFpafg {   display: flex;   background: #715AD0;   height: 30px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-left: 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #fff;   width: 220px } .aCghKjvYpWzCgAaWCcTKTw .nGPMFMobfmgrQaeXkFpafg:after{   position: absolute;   right: 102%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .aCghKjvYpWzCgAaWCcTKTw .nGPMFMobfmgrQaeXkFpafg:before{   position: absolute;   right: -2%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; } .aCghKjvYpWzCgAaWCcTKTw .nGPMFMobfmgrQaeXkFpafg span {   color: #fff;   font-size: 13px;   line-height: 13px; } .aCghKjvYpWzCgAaWCcTKTw .nGPMFMobfmgrQaeXkFpafg span:nth-child(2) {   display: none; } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg{   display: flex;   flex-direction: column;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 220px; } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg span {   color: #fff;   font-size: 13px;   line-height: 13px; } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg span:nth-child(2) {   display: none; } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg {   display: flex;   background: #715AD0;   height: 30px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-right: 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #fff;   width: 220px } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg:after{   position: absolute;   right: 102%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .aCghKjvYpWzCgAaWCcTKTw .nGhngTKEZZuFUAhYdfesDg:before{   position: absolute;   right: -2%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; }
.KffZdQpXmDsWdyLkFLNWFA {   width: 900px;   height: 44px;   margin: 0 auto;   background: #715AD0;   max-width: 100%;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; } .KffZdQpXmDsWdyLkFLNWFA:hover {   color: #fff; } .KffZdQpXmDsWdyLkFLNWFA:hover .yqybagsjcdswgVYiyNvUKQ span:nth-child(1) {   display: none; } .KffZdQpXmDsWdyLkFLNWFA:hover .yqybagsjcdswgVYiyNvUKQ span:nth-child(2) {   display: block; } .KffZdQpXmDsWdyLkFLNWFA:hover .UXhkyzkFRdiDZbExRsTXqQ span:nth-child(2) {   display: none; } .KffZdQpXmDsWdyLkFLNWFA:hover .UXhkyzkFRdiDZbExRsTXqQ span:nth-child(3) {   display: block; } .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA {   display: flex;   background: #fff;   height: 32px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-right: 1em;   position: relative;   z-index: 2;   font-size: 18px;   color: #000;   width: 150px } // forma mid 1 .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA:after{   position: absolute;   right: 90%;   top: 115%;   content: "";   width: 22px;   height: 22px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA:before{   position: absolute;   right: 10%;   top: -15%;   content: "";   width: 22px;   height: 22px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } // forma mid 2 .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA:after{   position: absolute;   right: 98%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA:before{   position: absolute;   right: 2%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA span {   font-size: 24px;   font-family: Existence;   font-weight: 600; } .KffZdQpXmDsWdyLkFLNWFA .RAuZeWLVhPNyLqDjMNUfCA span:hover {   color: #000;   text-decoration: none; } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ {   display: flex;   height: 44px;   flex-direction: column;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 230px; } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ:after{   position: absolute;   right: 81%;   top: 70%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ:before{   position: absolute;   right: 19%;   top: 70%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ span:nth-child(3) {   display: flex;   background: #fff;   height: 18px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-top: 0.35em;   position: relative;   z-index: 2;   font-size: 14px;   color: #000;   width: 130px } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ span {   color: #fff;   font-size: 13px;   line-height: 13px; } .KffZdQpXmDsWdyLkFLNWFA .yqybagsjcdswgVYiyNvUKQ span:nth-child(2) {   display: none; } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ{   display: flex;   flex-direction: column;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 230px; } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ span {   color: #fff;   font-size: 13px;   line-height: 13px; } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ span:nth-child(3) {   display: none; } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ span:nth-child(1) {   display: flex;   background: #fff;   height: 18px;   align-items: center;   justify-content: center;   border-radius: 5px;   margin-bottom: 0.35em;   padding: 0 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #000;   width: 130px } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ:after{   position: absolute;   right: 81%;   top: 30%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .KffZdQpXmDsWdyLkFLNWFA .UXhkyzkFRdiDZbExRsTXqQ:before{   position: absolute;   right: 19%;   top: 30%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; }
.asOeNpWccHfOihyMBVKajg {   background-color:#142155;   width:912px;   height:42px;   display:flex;   justify-content:flex-start;   align-items:center;   position:relative;   padding-left: 20px;   overflow: hidden; }  .asOeNpWccHfOihyMBVKajg > a {   position: absolute;   width: 932px;   height: 42px;   margin-left: -20px;   z-index: 44; }  .asOeNpWccHfOihyMBVKajg > img:nth-child(2) {   margin-right: 48px;   margin-bottom: 4px; }  .asOeNpWccHfOihyMBVKajg > img:nth-child(3) {   margin-right: 48px;   opacity: 1;   transition: opacity 0.2s linear, margin-left 0.2s cubic-bezier(0.05, 0.8, 0.05, 0.8) 0.1s, margin-right 0.2s cubic-bezier(0.05, 0.8, 0.05, 0.8) 0.3s; }  .asOeNpWccHfOihyMBVKajg > img:nth-child(4) {   margin-right: 14px;   transition: opacity 0.3s linear; }  .asOeNpWccHfOihyMBVKajg > .KtiflwuqbuyoLeRbjSlEfw {    background-color:#fff;    width:48px;    height:16px;    padding:4px 8px;    transition: opacity 0.3s linear; }  .asOeNpWccHfOihyMBVKajg > .KtiflwuqbuyoLeRbjSlEfw > img {    width:48px; }  .asOeNpWccHfOihyMBVKajg > svg {    position:absolute;    top:0;    left:-184px; }  .asOeNpWccHfOihyMBVKajg:hover > .zxskfEQcljTqJDwMgQcxuw > .jDYnILLdiqiyjGEfvgpejg {   right: 0;   transition: all 0.3s cubic-bezier(0.05, 0.8, 0.05, 0.8); } .asOeNpWccHfOihyMBVKajg:hover > img:nth-child(3) {   opacity: 0;   margin-left: 880px;   margin-right: 600px; } .asOeNpWccHfOihyMBVKajg:hover > img:nth-child(4) {   opacity: 0; } .asOeNpWccHfOihyMBVKajg:hover > .KtiflwuqbuyoLeRbjSlEfw {   opacity: 0; }  .zxskfEQcljTqJDwMgQcxuw {   position:absolute;   top:0;   right:0;   height:42px;   width:800px;   overflow: hidden; }  .zxskfEQcljTqJDwMgQcxuw > .jDYnILLdiqiyjGEfvgpejg {   position: absolute;   height:42px;   width:760px;   right: -820px;   top: 0;   background-color:#fff;   transition: all 0.2s cubic-bezier(0.8, 0.3, 0.8, 0.3); }  .zxskfEQcljTqJDwMgQcxuw > .jDYnILLdiqiyjGEfvgpejg::after {   content: "";   position: absolute;   border: 0px solid transparent;   border-top: 40px solid #fff;   border-left: 42px solid transparent;   width: 0;   height: 0;   top: 1px;   left: -40px;   transform: rotate(90deg); }  .zxskfEQcljTqJDwMgQcxuw > .jDYnILLdiqiyjGEfvgpejg > img {   margin-left: 185px;   margin-top: 11px; }
.BxkNagrjZxjKlJfBhwwoOg { 	width: 100%; 	max-height: 47px; 	height: 47px; 	border-radius: 8px; 	background: #009FFF; 	background: -webkit-linear-gradient(to right, #736df8, #ec2F4B); 	background: -webkit-gradient(linear, left top, right top, from(#736df8), to(#ec2F4B)); 	background: -webkit-linear-gradient(left, #736df8, #ec2F4B); 	background: -o-linear-gradient(left, #736df8, #ec2F4B); 	background: linear-gradient(to right, #736df8, #ec2F4B); 	color: #ffffff; 	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; 	text-decoration: none; 	display: -webkit-box; 	display: -ms-flexbox; 	display: flex; 	-ms-flex-pack: distribute; 	justify-content: space-around; 	-webkit-box-align: center; 	-ms-flex-align: center; 	align-items: center; 	position: relative; }  .CwyJZGGhqWxNihepygiyyQ { 	position: absolute; 	width: 100%; 	height: 100%; }  .uOEpLhcLDYiNLffgWhbxNg { 	background-color: #333648; 	padding: 8px 20px; 	border-radius: 1000px; 	text-align: center; 	-webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, .08); 	box-shadow: 0 5px 15px rgba(0, 0, 0, .08); 	text-transform: uppercase; 	letter-spacing: 0.0625em; 	font-weight: bold; 	font-size: 14px; 	color: #ffffff; 	text-decoration: none; 	cursor: pointer; }  .IqorzaikZTcJOfAcRQeTxw { 	display: -webkit-box; 	display: -ms-flexbox; 	display: flex; 	-webkit-box-pack: center; 	-ms-flex-pack: center; 	justify-content: center; 	-webkit-box-align: center; 	-ms-flex-align: center; 	align-items: center; 	font-size: 16px; }  .IqorzaikZTcJOfAcRQeTxw>span { 	margin-left: 8px; 	margin-right: 8px; }  .UyyefiTTciaVYhjEfiGkmA { 	font-size: 20px; }
.nounderline:hover {text-decoration:none}
.exempttable {display:inline-table !important}
.bbca table, .bbca tbody, .bbca tr, .bbca td{
	display: inline-block !important;
	min-width: 0px !important;
	text-align: center !important;
}
.gunbot td{text-align:left !important}
.olddiv{display:block}
.cryptokg {display:inline-block;padding:2px;font-size:17px;height:42px;width:500px;background-color:white; font-weight:700;color:orange} .cryptokg a:link{color:orange} .cryptokg a:hover{color:orange} .cryptokg a:visited{color:orange}
</style>
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/105.css" />
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/96.css" />
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/104.css" />


	<link rel="help" href="https://bitcointalk.org/index.php?action=help" target="_blank" />
	<link rel="search" href="https://bitcointalk.org/index.php?action=search" />
	<link rel="contents" href="https://bitcointalk.org/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Bitcoin Forum - RSS" href="https://bitcointalk.org/index.php?type=rss;action=.xml" /><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />

	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var current_header = false;

		function shrinkHeader(mode)
		{
			document.cookie = "upshrink=" + (mode ? 1 : 0);
			document.getElementById("upshrink").src = smf_images_url + (mode ? "/upshrink2.gif" : "/upshrink.gif");

			document.getElementById("upshrinkHeader").style.display = mode ? "none" : "";
			document.getElementById("upshrinkHeader2").style.display = mode ? "none" : "";

			current_header = mode;
		}
	// ]]></script>
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			var current_header_ic = false;

			function shrinkHeaderIC(mode)
			{
				document.cookie = "upshrinkIC=" + (mode ? 1 : 0);
				document.getElementById("upshrink_ic").src = smf_images_url + (mode ? "/expand.gif" : "/collapse.gif");

				document.getElementById("upshrinkHeaderIC").style.display = mode ? "none" : "";

				current_header_ic = mode;
			}
		// ]]></script></head>
<body>
	<div class="tborder" >
		<table width="100%" cellpadding="0" cellspacing="0" border="0" id="smfheader">
			<tr>
				<td class="catbg" height="32">
					<span style="font-family: Verdana, sans-serif; font-size: 140%; ">Bitcoin Forum</span>
				</td>
				<td align="right" class="catbg">
					<img src="https://bitcointalk.org/Themes/custom1/images/smflogo.gif" style="margin: 2px;" alt="" />
				</td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" >
			<tr>
				<td class="titlebg2" height="32" align="right">
					<span class="smalltext">August 21, 2022, 05:18:42 PM</span>
					<a href="#" onclick="shrinkHeader(!current_header); return false;"><img id="upshrink" src="https://bitcointalk.org/Themes/custom1/images/upshrink.gif" alt="*" title="Shrink or expand the header." align="bottom" style="margin: 0 1ex;" /></a>
				</td>
			</tr>
			<tr id="upshrinkHeader">
				<td valign="top" colspan="2">
					<table width="100%" class="bordercolor" cellpadding="8" cellspacing="1" border="0" style="margin-top: 1px;">
						<tr>
							<td colspan="2" width="100%" valign="top" class="windowbg2" id="variousheadlinks"><span class="middletext">Welcome, <b>Guest</b>. Please <a href="https://bitcointalk.org/index.php?action=login">login</a> or <a href="https://bitcointalk.org/index.php?action=register">register</a>.				</span>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table id="upshrinkHeader2" width="100%" cellpadding="4" cellspacing="0" border="0">
			<tr>
				<td width="90%" class="titlebg2">
					<span class="smalltext"><b>News</b>: Latest Bitcoin Core release: <a class="ul" href="https://bitcoincore.org/en/download/"><b>23.0</b></a> [<a class="ul" href="https://bitcointalk.org/bitcoin-23.0.torrent">Torrent</a>]</span>
				</td>
				<td class="titlebg2" align="right" nowrap="nowrap" valign="top">
					<form action="https://bitcointalk.org/index.php?action=search2" method="post" accept-charset="ISO-8859-1" style="margin: 0;">
						<a href="https://bitcointalk.org/index.php?action=search;advanced"><img src="https://bitcointalk.org/Themes/custom1/images/filter.gif" align="middle" style="margin: 0 1ex;" alt="" /></a>
						<input type="text" name="search" value="" style="width: 190px;" />&nbsp;
						<input type="submit" name="submit" value="Search" style="width: 11ex;" />
						<input type="hidden" name="advanced" value="0" />
					</form>
				</td>
			</tr>
		</table>
	</div>
			<table cellpadding="0" cellspacing="0" border="0" style="margin-left: 10px;">
				<tr>
					<td class="maintab_first">&nbsp;</td><td class="maintab_active_first">&nbsp;</td>
				<td valign="top" class="maintab_active_back">
					<a href="https://bitcointalk.org/index.php">Home</a>
				</td><td class="maintab_active_last">&nbsp;</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=help">Help</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=search">Search</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=login">Login</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=register">Register</a>
				</td>
                                <td valign="top" class="maintab_back">
                                        <a href="/more.php">More</a>
                                </td>
				<td class="maintab_last">&nbsp;</td>
			</tr>
		</table>
	<div id="bodyarea" style="padding: 1ex 0px 2ex 0px;">
<div class="tborder" style="margin-top: 1ex;">
	<div id="helpmenu" class="titlebg" style="padding: 4px;">Various links</div>
	<div style="padding: 2ex;" id="helpmain" class="windowbg2">
	<ul>
	<li><a href="/index.php?action=credit;promote">Buy a copper membership</a></li>
	<li><a href="/index.php?topic=5089777.0">Support for hacked/lost accounts</a></li>
	<li><a href="/donate.html">About donations</a></li>
	<li><a href="/privacy.php">About privacy</a></li>
	<li><a href="/sbounties.php">Security bounties</a></li>
	<li><a href="/contact.php">Contact</a></li>
	</ul>
	</div>
</div>

	</div><script type="text/javascript">
//<!--
Array.prototype.forEach.call(document.getElementsByClassName("userimg"), checkImg);
//-->
</script>

	<div id="footerarea" style="text-align: center; padding-bottom: 1ex;">
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function smfFooterHighlight(element, value)
			{
				element.src = smf_images_url + "/" + (value ? "h_" : "") + element.id + ".gif";
			}
		// ]]></script>
		<table cellspacing="0" cellpadding="3" border="0" align="center" width="100%">
			<tr>
				<td width="28%" valign="middle" align="right">
					<a href="http://www.mysql.com/" target="_blank"><img id="powered-mysql" src="https://bitcointalk.org/Themes/custom1/images/powered-mysql.gif" alt="Powered by MySQL" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
					<a href="http://www.php.net/" target="_blank"><img id="powered-php" src="https://bitcointalk.org/Themes/custom1/images/powered-php.gif" alt="Powered by PHP" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
				</td>
				<td valign="middle" align="center" style="white-space: nowrap;">
					
		<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;">
		</span>
				</td>
				<td width="28%" valign="middle" align="left">
					<a href="http://validator.w3.org/check/referer" target="_blank"><img id="valid-xhtml10" src="https://bitcointalk.org/Themes/custom1/images/valid-xhtml10.gif" alt="Valid XHTML 1.0!" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
					<a href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank"><img id="valid-css" src="https://bitcointalk.org/Themes/custom1/images/valid-css.gif" alt="Valid CSS!" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
				</td>
			</tr>
		</table>
	</div>
	<div id="ajax_in_progress" style="display: none;">Loading...</div>
</body></html>