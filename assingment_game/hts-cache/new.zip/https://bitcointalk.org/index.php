<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml"><head>
	<meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1" />
	<meta name="description" content="Bitcoin Forum - Index" />
	
	<meta name="keywords" content="bitcoin, forum, bitcoin forum, bitcointalk" />
	<script language="JavaScript" type="text/javascript" src="https://bitcointalk.org/Themes/default/script.js"></script>
	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var smf_theme_url = "https://bitcointalk.org/Themes/custom1";
		var smf_images_url = "https://bitcointalk.org/Themes/custom1/images";
		var smf_scripturl = "https://bitcointalk.org/index.php";
		var smf_iso_case_folding = false;
		var smf_charset = "ISO-8859-1";
	// ]]></script>
	<title>Bitcoin Forum - Index</title><!--79c3c1c93ee52c790c253b5b162b69fe049accb94ae89f1cc8dad904252b0c253b5b162b69fe049accb94ae89f1cd1a7-->
	<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/custom1/style.css" />
	 <!--[if !IE]> -->
	 <link rel="stylesheet" type="text/css" media="only screen and (min-device-width: 320px) and (max-device-width: 650px)" href="https://bitcointalk.org/Themes/custom1/mobile.css" />
	 <!-- <![endif]-->
	<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/default/print.css" media="print" /><style type="text/css">
.GKDtvcoalJojHZcqhelMcA > td {background-color: #E5E5E8; text-align:center;}
.GKDtvcoalJojHZcqhelMcA > td > table {margin-top:-5px}
.GKDtvcoalJojHZcqhelMcA .cXaydhSVLqMRpmfREXyZuA {display:inline-block;max-width:100%; min-width:100%; max-height:47px; overflow:hidden}
.GKDtvcoalJojHZcqhelMcA table,.GKDtvcoalJojHZcqhelMcA tbody,.GKDtvcoalJojHZcqhelMcA tr,.GKDtvcoalJojHZcqhelMcA td {display:inline-block;max-width:100%; min-width:100%; overflow:hidden}
.GKDtvcoalJojHZcqhelMcA .cXaydhSVLqMRpmfREXyZuA table,.GKDtvcoalJojHZcqhelMcA .cXaydhSVLqMRpmfREXyZuA tbody,.GKDtvcoalJojHZcqhelMcA .cXaydhSVLqMRpmfREXyZuA tr,.GKDtvcoalJojHZcqhelMcA .cXaydhSVLqMRpmfREXyZuA td {display:initial; max-width:none;min-width:none;overflow:visible}
.QcXYQWvjxujzwyjkQJsbaQ {display:none !important}
.WjnxHythdnpeaPaUamBaDw {display:none}
.ewepfHojsxaMkjTkTRShmQ {padding: 1px 1px 0 1px;}
.IVdhitfWUuCNiasbeWOKiA{color:#699C62; font-weight:bold; font-size:18px}
.IVdhitfWUuCNiasbeWOKiA:link{color:#699C62; font-weight:bold; font-size:18px}
.IVdhitfWUuCNiasbeWOKiA:visited{color:#699C62; font-weight:bold; font-size:18px}
.xcccGkZHexbfRMtkufwiBw{color:#00F30C;font-size:15px;font-weight:bold}
.xcccGkZHexbfRMtkufwiBw:link{color:#00F30C;font-size:15px;font-weight:bold}
.xcccGkZHexbfRMtkufwiBw:visited{color:#00F30C;font-size:15px;font-weight:bold}
.byFxdbgqKxYgrcRgOVrRjw{font-size:x-small}

.KSczRjOzaMirGHdLgXihhA:link {font-size:22px;font-weight:bold;color:orange}
.KSczRjOzaMirGHdLgXihhA:active {font-size:22px;font-weight:bold;color:orange}
.KSczRjOzaMirGHdLgXihhA:visited {font-size:22px;font-weight:bold;color:orange}
.KSczRjOzaMirGHdLgXihhA:hover {text-decoration:none !important;color:red}
.HbHybVhQbNKbvifdxcbpcg:link {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.HbHybVhQbNKbvifdxcbpcg:active {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.HbHybVhQbNKbvifdxcbpcg:visited {font-size:24px;font-weight:bold;color:rgb(250,180,75)}
.HbHybVhQbNKbvifdxcbpcg:hover {text-decoration:none !important;color:white;background-color:rgb(181,204,222)}
.HbHybVhQbNKbvifdxcbpcg {display:inline-block;margin: 3px;0;3px;0}
.HydjaoxKiNhaadcFIuwmKw:hover {text-decoration:none !important;}
.HydjaoxKiNhaadcFIuwmKw {font-size:22px;font-weight:bold;}
.oShleabhkdvQgjydxndAjg {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .oShleabhkdvQgjydxndAjg button {     border: none;     background: #8EE000;     color: #fff;     outline: none;     font-size: 1em;     padding: 0.5em 1.2em;     margin-left: 0.3em;     border-radius: 2em;     text-transform: uppercase;     font-weight: 600;     pointer-events: none;   }    .oShleabhkdvQgjydxndAjg:hover .hgmyeejJoiDKCgflnhCPoA span {   display: none; }  .oShleabhkdvQgjydxndAjg:hover .hgmyeejJoiDKCgflnhCPoA span:nth-child(2) {   display: block; }  .hgmyeejJoiDKCgflnhCPoA {   display: flex;   align-items: center; }    .hgmyeejJoiDKCgflnhCPoA span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .UTxDKkWfncpeeblTnKahzQ {   display: inline-block; }  .hgmyeejJoiDKCgflnhCPoA span:nth-child(2) {   display: none; }  .shVFjpodxAjVjhhsJUgOZw {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .shVFjpodxAjVjhhsJUgOZw:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .shVFjpodxAjVjhhsJUgOZw > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .oShleabhkdvQgjydxndAjg button {     display: none;   }   .hgmyeejJoiDKCgflnhCPoA {     margin-left: 1em;   } }   @media (max-width: 550px) {   .shVFjpodxAjVjhhsJUgOZw span span {     display: none;   } }  @media (max-width: 465px) {   .shVFjpodxAjVjhhsJUgOZw {     display: none;   }   .oShleabhkdvQgjydxndAjg {     justify-content: center;   } }
.ffKRkCgJvyMDvhxBeJPUdQ {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .ffKRkCgJvyMDvhxBeJPUdQ button {     border: none;     background: #8EE000;     color: #fff;     outline: none;     font-size: 1em;     padding: 0.5em 1.2em;     margin-left: 0.4em;     border-radius: 2em;     text-transform: uppercase;     font-weight: 600; cursor:pointer; transition: all 0.3s;   } button:hover{transform: scale(1.05);}    .xkAoQeiihVHAiMffhUfhTw:hover span{   display: none; }  .xkAoQeiihVHAiMffhUfhTw:hover span:nth-child(2) {   display: block; }  .xkAoQeiihVHAiMffhUfhTw {   display: flex;   align-items: center; color:#fff}    .xkAoQeiihVHAiMffhUfhTw span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .wmDrjyzyCDfaxyUraibibQ {   display: inline-block; }  .xkAoQeiihVHAiMffhUfhTw span:nth-child(2) {   display: none; }  .gHdoiLaEyHZhUcgOOeWPNw {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .gHdoiLaEyHZhUcgOOeWPNw:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .gHdoiLaEyHZhUcgOOeWPNw > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .ffKRkCgJvyMDvhxBeJPUdQ button {     display: none;   }   .xkAoQeiihVHAiMffhUfhTw {     margin-left: 1em;   } }   @media (max-width: 550px) {   .gHdoiLaEyHZhUcgOOeWPNw span span {     display: none;   } }  @media (max-width: 465px) {   .gHdoiLaEyHZhUcgOOeWPNw {     display: none;   }   .ffKRkCgJvyMDvhxBeJPUdQ {     justify-content: center;   } }
.oShleabhkdvQgjydxndAjg {   width: 900px;   height: 44px;   max-width: 100%;   background: #5CB9F7;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .oShleabhkdvQgjydxndAjg button {   border: none;   background: #8EE000;   color: #fff;   outline: none;   font-size: 1em;   padding: 0.5em 1.2em;   margin-left: 0.4em;   border-radius: 2em;   text-transform: uppercase;   font-weight: 600;   cursor: pointer;   transition: all 0.3s; }  button:hover {   transform: scale(1.05); }  .hgmyeejJoiDKCgflnhCPoA:hover span {   display: none; }  .hgmyeejJoiDKCgflnhCPoA:hover span:nth-child(2) {   display: block; }  .hgmyeejJoiDKCgflnhCPoA {   display: flex;   align-items: center;   color: #fff; }    .hgmyeejJoiDKCgflnhCPoA span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .UTxDKkWfncpeeblTnKahzQ {   display: inline-block; }  .hgmyeejJoiDKCgflnhCPoA span:nth-child(2) {   display: none; }  .shVFjpodxAjVjhhsJUgOZw {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .shVFjpodxAjVjhhsJUgOZw:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .shVFjpodxAjVjhhsJUgOZw > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .oShleabhkdvQgjydxndAjg button {     display: none;   }   .hgmyeejJoiDKCgflnhCPoA {     margin-left: 1em;   } }   @media (max-width: 550px) {   .shVFjpodxAjVjhhsJUgOZw span span {     display: none;   } }  @media (max-width: 465px) {   .shVFjpodxAjVjhhsJUgOZw {     display: none;   }   .oShleabhkdvQgjydxndAjg {     justify-content: center;   } }
.ffKRkCgJvyMDvhxBeJPUdQ {   width: 900px;   height: 44px;   max-width: 100%;   background: #fff;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   font-size: 16px;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; }    .ffKRkCgJvyMDvhxBeJPUdQ button {   border: none;   background: #8EE000;   color: #fff;   outline: none;   font-size: 1em;   padding: 0.5em 1.2em;   margin-left: 0.4em;   border-radius: 2em;   text-transform: uppercase;   font-weight: 600;   cursor: pointer;   transition: all 0.3s; }  button:hover {   transform: scale(1.05); }  .xkAoQeiihVHAiMffhUfhTw:hover span {   display: none; }  .xkAoQeiihVHAiMffhUfhTw:hover span:nth-child(2) {   display: block; }  .xkAoQeiihVHAiMffhUfhTw {   display: flex;   align-items: center;   color: #5CB9F7; }    .xkAoQeiihVHAiMffhUfhTw span {   margin-left: 0.1em;   font-size: 1em;   font-weight: 700;   letter-spacing: 0.5px;   font-size: 20px;   width: 11em;   text-align: center; }  .wmDrjyzyCDfaxyUraibibQ {   display: inline-block; }  .xkAoQeiihVHAiMffhUfhTw span:nth-child(2) {   display: none; }  .gHdoiLaEyHZhUcgOOeWPNw {   display: flex;   background: #586A91;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em 0 0.5em;   position: relative;   z-index: 2; }    .gHdoiLaEyHZhUcgOOeWPNw:after {   position: absolute;   right: 100%;   top: 50%;   content: "";   width: 36px;   height: 36px;   background: #586A91;   border-radius: 0.5em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; }    .gHdoiLaEyHZhUcgOOeWPNw > span {   margin-right: 1em;   font-weight: 600;   font-size: 16px;   letter-spacing: 0.5px;   margin-top: 0.1em; }  @media (max-width: 725px) {   .ffKRkCgJvyMDvhxBeJPUdQ button {     display: none;   }   .xkAoQeiihVHAiMffhUfhTw {     margin-left: 1em;   } }   @media (max-width: 550px) {   .gHdoiLaEyHZhUcgOOeWPNw span span {     display: none;   } }  @media (max-width: 465px) {   .gHdoiLaEyHZhUcgOOeWPNw {     display: none;   }   .ffKRkCgJvyMDvhxBeJPUdQ {     justify-content: center;   } }
.IibvjXSheanfjthKzvQXBA {   width: 900px;   height: 44px;   margin: 0 auto;   background: #fff;   max-width: 100%;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   color: #000 !important;   font-family: arial, sans-serif;   overflow: hidden; } .IibvjXSheanfjthKzvQXBA:hover {   color: #fff;   background: #715AD0; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig span:nth-child(1) {   display: none; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig span:nth-child(2) {   display: block; } .IibvjXSheanfjthKzvQXBA:hover .YayjsihxaiVKNysgXmWaSg span:nth-child(1) {   display: none;   color: #000; } .IibvjXSheanfjthKzvQXBA:hover .YayjsihxaiVKNysgXmWaSg span:nth-child(2) {   display: block;   color: #000; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig {   background: #fff;   color: #000; } .IibvjXSheanfjthKzvQXBA:hover .YayjsihxaiVKNysgXmWaSg {   background: #fff;   color: #000; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig:after {   background: #715AD0; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig:before {   background: #715AD0; } .IibvjXSheanfjthKzvQXBA:hover .xWWiUUjdYsBajpOrxvRbig span {   color: #000; } .IibvjXSheanfjthKzvQXBA:hover .YayjsihxaiVKNysgXmWaSg:after {   background: #715AD0; } .IibvjXSheanfjthKzvQXBA:hover .YayjsihxaiVKNysgXmWaSg:before {   background: #715AD0; } .IibvjXSheanfjthKzvQXBA:hover .nnlcJygqEQXndOsGFbAVGw {   color: #fff; } .IibvjXSheanfjthKzvQXBA:hover .nnlcJygqEQXndOsGFbAVGw:before {   background: #fff; } .IibvjXSheanfjthKzvQXBA:hover .nnlcJygqEQXndOsGFbAVGw:after {   background: #fff; } .IibvjXSheanfjthKzvQXBA .nnlcJygqEQXndOsGFbAVGw {   display: flex;   height: 32px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   position: relative;   z-index: 2;   font-size: 18px;   color: #000;   width: 160px; } .IibvjXSheanfjthKzvQXBA .nnlcJygqEQXndOsGFbAVGw:after{   position: absolute;   right: 98%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .IibvjXSheanfjthKzvQXBA .nnlcJygqEQXndOsGFbAVGw:before{   position: absolute;   right: 2%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .IibvjXSheanfjthKzvQXBA .nnlcJygqEQXndOsGFbAVGw span {   font-size: 26px;   font-family: Existence;   font-weight: 600; } .IibvjXSheanfjthKzvQXBA .nnlcJygqEQXndOsGFbAVGw span:hover {   color: #fff;   text-decoration: none; } .IibvjXSheanfjthKzvQXBA .xWWiUUjdYsBajpOrxvRbig {   display: flex;   background: #715AD0;   height: 30px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-left: 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #fff;   width: 220px } .IibvjXSheanfjthKzvQXBA .xWWiUUjdYsBajpOrxvRbig:after{   position: absolute;   right: 102%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .IibvjXSheanfjthKzvQXBA .xWWiUUjdYsBajpOrxvRbig:before{   position: absolute;   right: -2%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; } .IibvjXSheanfjthKzvQXBA .xWWiUUjdYsBajpOrxvRbig span {   color: #fff;   font-size: 13px;   line-height: 13px; } .IibvjXSheanfjthKzvQXBA .xWWiUUjdYsBajpOrxvRbig span:nth-child(2) {   display: none; } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg{   display: flex;   flex-direction: column;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 220px; } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg span {   color: #fff;   font-size: 13px;   line-height: 13px; } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg span:nth-child(2) {   display: none; } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg {   display: flex;   background: #715AD0;   height: 30px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-right: 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #fff;   width: 220px } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg:after{   position: absolute;   right: 102%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .IibvjXSheanfjthKzvQXBA .YayjsihxaiVKNysgXmWaSg:before{   position: absolute;   right: -2%;   top: 50%;   content: "";   width: 18px;   height: 18px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; }
.nGhngTKEZZuFUAhYdfesDg {   width: 900px;   height: 44px;   margin: 0 auto;   background: #715AD0;   max-width: 100%;   display: flex;   justify-content: space-between;   align-items: center;   text-decoration: none !important;   color: #fff !important;   font-family: arial, sans-serif;   overflow: hidden; } .nGhngTKEZZuFUAhYdfesDg:hover {   color: #fff; } .nGhngTKEZZuFUAhYdfesDg:hover .nGPMFMobfmgrQaeXkFpafg span:nth-child(1) {   display: none; } .nGhngTKEZZuFUAhYdfesDg:hover .nGPMFMobfmgrQaeXkFpafg span:nth-child(2) {   display: block; } .nGhngTKEZZuFUAhYdfesDg:hover .GstdvDfHhDhdvQolOJyxDg span:nth-child(2) {   display: none; } .nGhngTKEZZuFUAhYdfesDg:hover .GstdvDfHhDhdvQolOJyxDg span:nth-child(3) {   display: block; } .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg {   display: flex;   background: #fff;   height: 32px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-right: 1em;   position: relative;   z-index: 2;   font-size: 18px;   color: #000;   width: 150px } // forma mid 1 .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg:after{   position: absolute;   right: 90%;   top: 115%;   content: "";   width: 22px;   height: 22px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg:before{   position: absolute;   right: 10%;   top: -15%;   content: "";   width: 22px;   height: 22px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } // forma mid 2 .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg:after{   position: absolute;   right: 98%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg:before{   position: absolute;   right: 2%;   top: 50%;   content: "";   width: 25px;   height: 25px;   background: #fff;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: -1; } .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg span {   font-size: 24px;   font-family: Existence;   font-weight: 600; } .nGhngTKEZZuFUAhYdfesDg .xUgLfhdIIUpqfdDwduRmhg span:hover {   color: #000;   text-decoration: none; } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg {   display: flex;   height: 44px;   flex-direction: column;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 230px; } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg:after{   position: absolute;   right: 81%;   top: 70%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg:before{   position: absolute;   right: 19%;   top: 70%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg span:nth-child(3) {   display: flex;   background: #fff;   height: 18px;   align-items: center;   justify-content: center;   border-radius: 5px;   padding: 0 1em;   margin-top: 0.35em;   position: relative;   z-index: 2;   font-size: 14px;   color: #000;   width: 130px } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg span {   color: #fff;   font-size: 13px;   line-height: 13px; } .nGhngTKEZZuFUAhYdfesDg .nGPMFMobfmgrQaeXkFpafg span:nth-child(2) {   display: none; } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg{   display: flex;   flex-direction: column;   height: 44px;   align-items: center;   justify-content: center;   padding: 0 1em;   position: relative;   z-index: 2;   width: 230px; } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg span {   color: #fff;   font-size: 13px;   line-height: 13px; } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg span:nth-child(3) {   display: none; } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg span:nth-child(1) {   display: flex;   background: #fff;   height: 18px;   align-items: center;   justify-content: center;   border-radius: 5px;   margin-bottom: 0.35em;   padding: 0 1em;   position: relative;   z-index: 2;   font-size: 14px;   color: #000;   width: 130px } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg:after{   position: absolute;   right: 81%;   top: 30%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 2; } .nGhngTKEZZuFUAhYdfesDg .GstdvDfHhDhdvQolOJyxDg:before{   position: absolute;   right: 19%;   top: 30%;   content: "";   width: 14px;   height: 14px;   background: #715AD0;   border-radius: 0.3em;   transform: translate(50%, -50%) rotate(45deg);   z-index: 3; }
.yqybagsjcdswgVYiyNvUKQ {   background-color:#142155;   width:912px;   height:42px;   display:flex;   justify-content:flex-start;   align-items:center;   position:relative;   padding-left: 20px;   overflow: hidden; }  .yqybagsjcdswgVYiyNvUKQ > a {   position: absolute;   width: 932px;   height: 42px;   margin-left: -20px;   z-index: 44; }  .yqybagsjcdswgVYiyNvUKQ > img:nth-child(2) {   margin-right: 48px;   margin-bottom: 4px; }  .yqybagsjcdswgVYiyNvUKQ > img:nth-child(3) {   margin-right: 48px;   opacity: 1;   transition: opacity 0.2s linear, margin-left 0.2s cubic-bezier(0.05, 0.8, 0.05, 0.8) 0.1s, margin-right 0.2s cubic-bezier(0.05, 0.8, 0.05, 0.8) 0.3s; }  .yqybagsjcdswgVYiyNvUKQ > img:nth-child(4) {   margin-right: 14px;   transition: opacity 0.3s linear; }  .yqybagsjcdswgVYiyNvUKQ > .RAuZeWLVhPNyLqDjMNUfCA {    background-color:#fff;    width:48px;    height:16px;    padding:4px 8px;    transition: opacity 0.3s linear; }  .yqybagsjcdswgVYiyNvUKQ > .RAuZeWLVhPNyLqDjMNUfCA > img {    width:48px; }  .yqybagsjcdswgVYiyNvUKQ > svg {    position:absolute;    top:0;    left:-184px; }  .yqybagsjcdswgVYiyNvUKQ:hover > .UXhkyzkFRdiDZbExRsTXqQ > .HOIgxDwCjKXjCrSILYaslg {   right: 0;   transition: all 0.3s cubic-bezier(0.05, 0.8, 0.05, 0.8); } .yqybagsjcdswgVYiyNvUKQ:hover > img:nth-child(3) {   opacity: 0;   margin-left: 880px;   margin-right: 600px; } .yqybagsjcdswgVYiyNvUKQ:hover > img:nth-child(4) {   opacity: 0; } .yqybagsjcdswgVYiyNvUKQ:hover > .RAuZeWLVhPNyLqDjMNUfCA {   opacity: 0; }  .UXhkyzkFRdiDZbExRsTXqQ {   position:absolute;   top:0;   right:0;   height:42px;   width:800px;   overflow: hidden; }  .UXhkyzkFRdiDZbExRsTXqQ > .HOIgxDwCjKXjCrSILYaslg {   position: absolute;   height:42px;   width:760px;   right: -820px;   top: 0;   background-color:#fff;   transition: all 0.2s cubic-bezier(0.8, 0.3, 0.8, 0.3); }  .UXhkyzkFRdiDZbExRsTXqQ > .HOIgxDwCjKXjCrSILYaslg::after {   content: "";   position: absolute;   border: 0px solid transparent;   border-top: 40px solid #fff;   border-left: 42px solid transparent;   width: 0;   height: 0;   top: 1px;   left: -40px;   transform: rotate(90deg); }  .UXhkyzkFRdiDZbExRsTXqQ > .HOIgxDwCjKXjCrSILYaslg > img {   margin-left: 185px;   margin-top: 11px; }
.kvYCgFsKhqqehojdfeBhhA { 	width: 100%; 	max-height: 47px; 	height: 47px; 	border-radius: 8px; 	background: #009FFF; 	background: -webkit-linear-gradient(to right, #736df8, #ec2F4B); 	background: -webkit-gradient(linear, left top, right top, from(#736df8), to(#ec2F4B)); 	background: -webkit-linear-gradient(left, #736df8, #ec2F4B); 	background: -o-linear-gradient(left, #736df8, #ec2F4B); 	background: linear-gradient(to right, #736df8, #ec2F4B); 	color: #ffffff; 	font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Oxygen-Sans, Ubuntu, Cantarell, "Helvetica Neue", sans-serif; 	text-decoration: none; 	display: -webkit-box; 	display: -ms-flexbox; 	display: flex; 	-ms-flex-pack: distribute; 	justify-content: space-around; 	-webkit-box-align: center; 	-ms-flex-align: center; 	align-items: center; 	position: relative; }  .KtiflwuqbuyoLeRbjSlEfw { 	position: absolute; 	width: 100%; 	height: 100%; }  .zxskfEQcljTqJDwMgQcxuw { 	background-color: #333648; 	padding: 8px 20px; 	border-radius: 1000px; 	text-align: center; 	-webkit-box-shadow: 0 5px 15px rgba(0, 0, 0, .08); 	box-shadow: 0 5px 15px rgba(0, 0, 0, .08); 	text-transform: uppercase; 	letter-spacing: 0.0625em; 	font-weight: bold; 	font-size: 14px; 	color: #ffffff; 	text-decoration: none; 	cursor: pointer; }  .jDYnILLdiqiyjGEfvgpejg { 	display: -webkit-box; 	display: -ms-flexbox; 	display: flex; 	-webkit-box-pack: center; 	-ms-flex-pack: center; 	justify-content: center; 	-webkit-box-align: center; 	-ms-flex-align: center; 	align-items: center; 	font-size: 16px; }  .jDYnILLdiqiyjGEfvgpejg>span { 	margin-left: 8px; 	margin-right: 8px; }  .iQGipafjsidsubjXdboaRw { 	font-size: 20px; }
.nounderline:hover {text-decoration:none}
.exempttable {display:inline-table !important}
.bbca table, .bbca tbody, .bbca tr, .bbca td{
	display: inline-block !important;
	min-width: 0px !important;
	text-align: center !important;
}
.gunbot td{text-align:left !important}
.olddiv{display:block}
.cryptokg {display:inline-block;padding:2px;font-size:17px;height:42px;width:500px;background-color:white; font-weight:700;color:orange} .cryptokg a:link{color:orange} .cryptokg a:hover{color:orange} .cryptokg a:visited{color:orange}
</style>
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/105.css" />
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/96.css" />
<link rel="stylesheet" type="text/css" href="https://bitcointalk.org/Themes/ac/104.css" />


	<link rel="help" href="https://bitcointalk.org/index.php?action=help" target="_blank" />
	<link rel="search" href="https://bitcointalk.org/index.php?action=search" />
	<link rel="contents" href="https://bitcointalk.org/index.php" />
	<link rel="alternate" type="application/rss+xml" title="Bitcoin Forum - RSS" href="https://bitcointalk.org/index.php?type=rss;action=.xml" /><meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />

	<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
		var current_header = false;

		function shrinkHeader(mode)
		{
			document.cookie = "upshrink=" + (mode ? 1 : 0);
			document.getElementById("upshrink").src = smf_images_url + (mode ? "/upshrink2.gif" : "/upshrink.gif");

			document.getElementById("upshrinkHeader").style.display = mode ? "none" : "";
			document.getElementById("upshrinkHeader2").style.display = mode ? "none" : "";

			current_header = mode;
		}
	// ]]></script>
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			var current_header_ic = false;

			function shrinkHeaderIC(mode)
			{
				document.cookie = "upshrinkIC=" + (mode ? 1 : 0);
				document.getElementById("upshrink_ic").src = smf_images_url + (mode ? "/expand.gif" : "/collapse.gif");

				document.getElementById("upshrinkHeaderIC").style.display = mode ? "none" : "";

				current_header_ic = mode;
			}
		// ]]></script></head>
<body>
	<div class="tborder" >
		<table width="100%" cellpadding="0" cellspacing="0" border="0" id="smfheader">
			<tr>
				<td class="catbg" height="32">
					<span style="font-family: Verdana, sans-serif; font-size: 140%; ">Bitcoin Forum</span>
				</td>
				<td align="right" class="catbg">
					<img src="https://bitcointalk.org/Themes/custom1/images/smflogo.gif" style="margin: 2px;" alt="" />
				</td>
			</tr>
		</table>
		<table width="100%" cellpadding="0" cellspacing="0" border="0" >
			<tr>
				<td class="titlebg2" height="32" align="right">
					<span class="smalltext">August 21, 2022, 05:18:33 PM</span>
					<a href="#" onclick="shrinkHeader(!current_header); return false;"><img id="upshrink" src="https://bitcointalk.org/Themes/custom1/images/upshrink.gif" alt="*" title="Shrink or expand the header." align="bottom" style="margin: 0 1ex;" /></a>
				</td>
			</tr>
			<tr id="upshrinkHeader">
				<td valign="top" colspan="2">
					<table width="100%" class="bordercolor" cellpadding="8" cellspacing="1" border="0" style="margin-top: 1px;">
						<tr>
							<td colspan="2" width="100%" valign="top" class="windowbg2" id="variousheadlinks"><span class="middletext">Welcome, <b>Guest</b>. Please <a href="https://bitcointalk.org/index.php?action=login">login</a> or <a href="https://bitcointalk.org/index.php?action=register">register</a>.				</span>
							</td>
						</tr>
					</table>
				</td>
			</tr>
		</table>
		<table id="upshrinkHeader2" width="100%" cellpadding="4" cellspacing="0" border="0">
			<tr>
				<td width="90%" class="titlebg2">
					<span class="smalltext"><b>News</b>: Latest Bitcoin Core release: <a class="ul" href="https://bitcoincore.org/en/download/"><b>23.0</b></a> [<a class="ul" href="https://bitcointalk.org/bitcoin-23.0.torrent">Torrent</a>]</span>
				</td>
				<td class="titlebg2" align="right" nowrap="nowrap" valign="top">
					<form action="https://bitcointalk.org/index.php?action=search2" method="post" accept-charset="ISO-8859-1" style="margin: 0;">
						<a href="https://bitcointalk.org/index.php?action=search;advanced"><img src="https://bitcointalk.org/Themes/custom1/images/filter.gif" align="middle" style="margin: 0 1ex;" alt="" /></a>
						<input type="text" name="search" value="" style="width: 190px;" />&nbsp;
						<input type="submit" name="submit" value="Search" style="width: 11ex;" />
						<input type="hidden" name="advanced" value="0" />
					</form>
				</td>
			</tr>
		</table>
	</div>
			<table cellpadding="0" cellspacing="0" border="0" style="margin-left: 10px;">
				<tr>
					<td class="maintab_first">&nbsp;</td><td class="maintab_active_first">&nbsp;</td>
				<td valign="top" class="maintab_active_back">
					<a href="https://bitcointalk.org/index.php">Home</a>
				</td><td class="maintab_active_last">&nbsp;</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=help">Help</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=search">Search</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=login">Login</a>
				</td>
				<td valign="top" class="maintab_back">
					<a href="https://bitcointalk.org/index.php?action=register">Register</a>
				</td>
                                <td valign="top" class="maintab_back">
                                        <a href="/more.php">More</a>
                                </td>
				<td class="maintab_last">&nbsp;</td>
			</tr>
		</table>
	<div id="bodyarea" style="padding: 1ex 0px 2ex 0px;">
	<table width="100%" cellpadding="0" cellspacing="0">
		<tr>
			<td valign="bottom"><div class="nav" style="font-size: smaller; margin-bottom: 2ex; margin-top: 2ex;"><b><a href="https://bitcointalk.org/index.php" class="nav">Bitcoin Forum</a></b></div></td>
			<td align="right">
			</td>
		</tr>
	</table>
	<div class="tborder" style="margin-top: 0;">
		<div class="catbg" style="padding: 5px 5px 5px 10px;">
				<a name="1" href="https://bitcointalk.org/index.php#1">Bitcoin</a>
		</div>
		<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor" style="margin-top: 1px;">
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=1.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=1.0" name="b1">Bitcoin Discussion</a></b><br />
						General discussion about the Bitcoin ecosystem that doesn't fit better elsewhere. News, the Bitcoin community, innovations, the general environment, etc. Discussion of specific Bitcoin-related services usually belongs in other sections.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=164822" title="Board Moderator">hilariousandco</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					2458028 Posts <br />
					96855 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1112467">goldkingcoiner</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5399221.msg60795845#new" title="Re:  Do you own 1 Bitcoin? (2022 edition)">Re:  Do you own 1 Bitcoi...</a><br />
						on <b>Today</b> at 05:06:03 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=74.0" title="No New Posts (Topics: 2559, Posts: 57500)">Legal</a>, <a href="https://bitcointalk.org/index.php?board=77.0" title="No New Posts (Topics: 34659, Posts: 126576)">Press</a>, <a href="https://bitcointalk.org/index.php?board=86.0" title="No New Posts (Topics: 1785, Posts: 12741)">Meetups</a>, <a href="https://bitcointalk.org/index.php?board=87.0" title="No New Posts (Topics: 53, Posts: 128)">Important Announcements</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=6.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=6.0" name="b6">Development &amp; Technical Discussion</a></b><br />
						Technical discussion about Satoshi's Bitcoin client and the Bitcoin network in general. No third-party sites/clients, bug reports that do not require much discussion (use github), or support requests.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=11425" title="Board Moderator">gmaxwell</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=290195" title="Board Moderator">achow101</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					303060 Posts <br />
					23724 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3496627">Phu Juck</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410706.msg60795845#new" title="Bitcoin � most important technical characteristics">Bitcoin � most important...</a><br />
						on <b>Today</b> at 04:48:00 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=37.0" title="No New Posts (Topics: 11241, Posts: 132155)">Wallet software</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=14.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=14.0" name="b14">Mining</a></b><br />
						Generating bitcoins.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=11425" title="Board Moderator">gmaxwell</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					950054 Posts <br />
					26662 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=2033515">mikeywith</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5297994.msg60795845#new" title="Re: Where to fix your Asic miners.">Re: Where to fix your As...</a><br />
						on <b>Today</b> at 04:25:32 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=40.0" title="No New Posts (Topics: 7234, Posts: 59113)">Mining support</a>, <a href="https://bitcointalk.org/index.php?board=41.0" title="No New Posts (Topics: 2018, Posts: 210385)">Pools</a>, <a href="https://bitcointalk.org/index.php?board=42.0" title="No New Posts (Topics: 1570, Posts: 60530)">Mining software (miners)</a>, <a href="https://bitcointalk.org/index.php?board=76.0" title="No New Posts (Topics: 6634, Posts: 464852)">Hardware</a>, <a href="https://bitcointalk.org/index.php?board=81.0" title="No New Posts (Topics: 3769, Posts: 75219)">Mining speculation</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=4.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=4.0" name="b4">Bitcoin Technical Support</a></b><br />
						Questions regarding issues with Bitcoin Core, nodes, the Bitcoin network, transactions, and addresses.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=290195" title="Board Moderator">achow101</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					108835 Posts <br />
					12366 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1188543">o_e_l_e_o</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410637.msg60795845#new" title="Re: Need help recovering funds from forgotten wallet on pre-'15 blockchain(bug)">Re: Need help recovering...</a><br />
						on <b>Today</b> at 01:57:24 PM
					</span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=12.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=12.0" name="b12">Project Development</a></b><br />
						Organization of Bitcoin and related projects, bounty campaigns, advertising etc.
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					179780 Posts <br />
					15683 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3497672">chibbit</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410684.msg60795845#new" title="Re: I want to deployment the project through the website">Re: I want to deployment...</a><br />
						on <b>Today</b> at 04:30:26 PM
					</span>
				</td>
			</tr>
		</table>
	</div>
	<div class="tborder" style="margin-top: 1ex;">
		<div class="catbg" style="padding: 5px 5px 5px 10px;">
				<a name="3" href="https://bitcointalk.org/index.php#3">Economy</a>
		</div>
		<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor" style="margin-top: 1px;">
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=7.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=7.0" name="b7">Economics</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					2672888 Posts <br />
					34008 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=110685">ChartBuddy</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=178336.msg60795845#new" title="Automated posting">Automated posting</a><br />
						on <b>Today</b> at 05:01:18 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=57.0" title="No New Posts (Topics: 21375, Posts: 1674003)">Speculation</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=5.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=5.0" name="b5">Marketplace</a></b><br />
						General marketplace discussion.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=78147" title="Board Moderator">Cyrus</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=164822" title="Board Moderator">hilariousandco</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					9271466 Posts <br />
					426418 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=664839">virasisog</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5391224.msg60795845#new" title="Re: Crypto Gambling Review Site">Re: Crypto Gambling Revi...</a><br />
						on <b>Today</b> at 05:15:58 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=51.0" title="No New Posts (Topics: 219141, Posts: 1814640)">Goods</a>, <a href="https://bitcointalk.org/index.php?board=52.0" title="No New Posts (Topics: 38484, Posts: 699781)">Services</a>, <a href="https://bitcointalk.org/index.php?board=53.0" title="No New Posts (Topics: 26911, Posts: 185659)">Currency exchange</a>, <a href="https://bitcointalk.org/index.php?board=56.0" title="No New Posts (Topics: 45597, Posts: 4516224)">Gambling</a>, <a href="https://bitcointalk.org/index.php?board=65.0" title="No New Posts (Topics: 11035, Posts: 193792)">Lending</a>, <a href="https://bitcointalk.org/index.php?board=78.0" title="No New Posts (Topics: 2358, Posts: 209240)">Securities</a>, <a href="https://bitcointalk.org/index.php?board=73.0" title="No New Posts (Topics: 10778, Posts: 122992)">Auctions</a>, <a href="https://bitcointalk.org/index.php?board=84.0" title="No New Posts (Topics: 28615, Posts: 663783)">Service Announcements</a>, <a href="https://bitcointalk.org/index.php?board=85.0" title="No New Posts (Topics: 37226, Posts: 740354)">Service Discussion</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=8.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=8.0" name="b8">Trading Discussion</a></b><br />
						Discussion about doing business with Bitcoin. Best trading practices, delivery methods etc.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=78147" title="Board Moderator">Cyrus</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					938751 Posts <br />
					37105 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=2344286">Little Mouse</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410699.msg60795845#new" title="Re: Need Community Feedback About Exposing Old Accounts">Re: Need Community Feedb...</a><br />
						on <b>Today</b> at 05:12:43 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=83.0" title="No New Posts (Topics: 15444, Posts: 236973)">Scam Accusations</a>, <a href="https://bitcointalk.org/index.php?board=129.0" title="No New Posts (Topics: 5236, Posts: 102338)">Reputation</a></span>
				</td>
			</tr>
		</table>
	</div>
	<div class="tborder" style="margin-top: 1ex;">
		<div class="catbg" style="padding: 5px 5px 5px 10px;">
				<a name="4" href="https://bitcointalk.org/index.php#4">Other</a>
		</div>
		<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor" style="margin-top: 1px;">
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=24.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=24.0" name="b24">Meta</a></b><br />
						Discussion about the Bitcoin Forum.
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					368717 Posts <br />
					19366 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1000813">PX-Z</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410682.msg60795845#new" title="Re: Why here people dont want to hear truth ?">Re: Why here people dont...</a><br />
						on <b>Today</b> at 05:15:49 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=167.0" title="No New Posts (Topics: 428, Posts: 5056)">New forum software</a>, <a href="https://bitcointalk.org/index.php?board=168.0" title="No New Posts (Topics: 85, Posts: 2010)">Bitcoin Wiki</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=34.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=34.0" name="b34">Politics &amp; Society</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					515824 Posts <br />
					16480 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3343941">Wakate</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409381.msg60795845#new" title="Re: I am seem to be jobless and not bothered. ">Re: I am seem to be jobl...</a><br />
						on <b>Today</b> at 05:09:29 PM
					</span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=39.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=39.0" name="b39">Beginners &amp; Help</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=14001" title="Board Moderator">MiningBuddy</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					778499 Posts <br />
					57940 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=327124">vv181</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410197.msg60795845#new" title="Re: Mailchimp was hacked again, exposing DigitalOcean customer's email">Re: Mailchimp was hacked...</a><br />
						on <b>Today</b> at 05:16:49 PM
					</span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=9.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=9.0" name="b9">Off-topic</a></b><br />
						Other topics that might be of interest to bitcoiners.
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					864338 Posts <br />
					32943 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3498270">DaveVoiting</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5400946.msg60795845#new" title="Re: Your favourite PC games?">Re: Your favourite PC ga...</a><br />
						on <b>Today</b> at 04:51:59 PM
					</span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=250.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=250.0" name="b250">Serious discussion</a></b><br />
						More serious discussion. No advertising of any kind. No junk posts.
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					13850 Posts <br />
					1081 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3454066">autumnleaf</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409966.msg60795845#new" title="Re: An easy way to overcome inflation ">Re: An easy way to overc...</a><br />
						on August 18, 2022, 02:29:42 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=251.0" title="No New Posts (Topics: 170, Posts: 2072)">Ivory Tower</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=59.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=59.0" name="b59">Archival</a></b><br />
						Old stuff.
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					333228 Posts <br />
					17432 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3498255">4nayz</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410547.msg60795845#new" title="test">test</a><br />
						on August 20, 2022, 12:29:11 AM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=92.0" title="No New Posts (Topics: 379, Posts: 16045)">&#1050;&#1086;&#1088;&#1079;&#1080;&#1085;&#1072;</a>, <a href="https://bitcointalk.org/index.php?board=44.0" title="No New Posts (Topics: 4215, Posts: 60950)">CPU/GPU Bitcoin mining hardware</a>, <a href="https://bitcointalk.org/index.php?board=17.0" title="No New Posts (Topics: 88, Posts: 560)">Chinese students</a>, <a href="https://bitcointalk.org/index.php?board=25.0" title="No New Posts (Topics: 393, Posts: 2492)">Obsolete (buying)</a>, <a href="https://bitcointalk.org/index.php?board=26.0" title="No New Posts (Topics: 1557, Posts: 9128)">Obsolete (selling)</a>, <a href="https://bitcointalk.org/index.php?board=99.0" title="No New Posts (Topics: 1103, Posts: 8372)">MultiBit</a></span>
				</td>
			</tr>
		</table>
	</div>
	<div class="tborder" style="margin-top: 1ex;">
		<div class="catbg" style="padding: 5px 5px 5px 10px;">
				<a name="6" href="https://bitcointalk.org/index.php#6">Alternate cryptocurrencies</a>
		</div>
		<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor" style="margin-top: 1px;">
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=67.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=67.0" name="b67">Altcoin Discussion</a></b><br />
						Discussion of cryptocurrencies other than Bitcoin. Note that discussion of how these currencies *relate to* Bitcoin may fit in other categories.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=51173" title="Board Moderator">mprep</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					3369216 Posts <br />
					105464 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1298138">m2017</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5406458.msg60795845#new" title="Re: How to know a good bounty">Re: How to know a good b...</a><br />
						on <b>Today</b> at 05:17:49 PM
					</span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=159.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=159.0" name="b159">Announcements (Altcoins)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=51173" title="Board Moderator">mprep</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=84521" title="Board Moderator">Welsh</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					8693198 Posts <br />
					50996 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=317618">nutildah</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=395761.msg60795845#new" title="Re: [ANN][XCP] Counterparty - Pioneering Peer-to-Peer Finance - Official Thread">Re: [ANN][XCP] Counterpa...</a><br />
						on <b>Today</b> at 05:16:17 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=240.0" title="No New Posts (Topics: 10855, Posts: 1502367)">Tokens (Altcoins)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=160.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=160.0" name="b160">Mining (Altcoins)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=51173" title="Board Moderator">mprep</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					859686 Posts <br />
					33778 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3482040">a1 Hashrate LLC2022</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410694.msg60795845#new" title="Re: ETH diff bomb what can a miner do?">Re: ETH diff bomb what c...</a><br />
						on <b>Today</b> at 05:04:17 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=199.0" title="No New Posts (Topics: 3179, Posts: 113880)">Pools (Altcoins)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=161.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=161.0" name="b161">Marketplace (Altcoins)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=51173" title="Board Moderator">mprep</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=84521" title="Board Moderator">Welsh</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					10450294 Posts <br />
					47252 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3487032">brsmax92</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409089.msg60795845#new" title="Re: &#128679; [BOUNTY] SOKOS.io - Digital Marketplace For NFT Collectibles">Re: &#128679; [BOUNTY] SOKOS.io ...</a><br />
						on <b>Today</b> at 05:18:30 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=197.0" title="No New Posts (Topics: 6845, Posts: 180764)">Service Announcements (Altcoins)</a>, <a href="https://bitcointalk.org/index.php?board=198.0" title="No New Posts (Topics: 7558, Posts: 232965)">Service Discussion (Altcoins)</a>, <a href="https://bitcointalk.org/index.php?board=238.0" title="No New Posts (Topics: 15646, Posts: 9815517)">Bounties (Altcoins)</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=224.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=224.0" name="b224">Speculation (Altcoins)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=51173" title="Board Moderator">mprep</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					1030698 Posts <br />
					14661 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3496627">Phu Juck</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5407066.msg60795845#new" title="Re: Will BTC Ever Reach $100k?">Re: Will BTC Ever Reach ...</a><br />
						on <b>Today</b> at 04:40:25 PM
					</span>
				</td>
			</tr>
		</table>
	</div>
	<div class="tborder" style="margin-top: 1ex;">
		<div class="catbg" style="padding: 5px 5px 5px 10px;">
				<a name="5" href="https://bitcointalk.org/index.php#5">Local</a>
		</div>
		<table border="0" width="100%" cellspacing="1" cellpadding="5" class="bordercolor" style="margin-top: 1px;">
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=241.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=241.0" name="b241">&#1575;&#1604;&#1593;&#1585;&#1576;&#1610;&#1577; (Arabic)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=375981" title="Board Moderator">OmegaStarScream</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					40574 Posts <br />
					5257 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=2443746">Kavelj22</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410063.msg60795845#new" title="Re: gate.io &#1578;&#1601;&#1585;&#1590; KYC &#1593;&#1604;&#1609; &#1605;&#1587;&#1578;&#1582;&#1583;&#1605;&#1610;&#1607;&#1575;">Re: gate.io &#1578;&#1601;&#1585;&#1590; KYC &#1593;&#1604;&#1609;...</a><br />
						on August 19, 2022, 11:43:23 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=242.0" title="No New Posts (Topics: 2538, Posts: 16669)">&#1575;&#1604;&#1593;&#1605;&#1604;&#1575;&#1578; &#1575;&#1604;&#1576;&#1583;&#1610;&#1604;&#1577; (Altcoins)</a>, <a href="https://bitcointalk.org/index.php?board=253.0" title="No New Posts (Topics: 699, Posts: 5081)">&#1573;&#1587;&#1578;&#1601;&#1587;&#1575;&#1585;&#1575;&#1578; &#1608; &#1571;&#1587;&#1574;&#1604;&#1577; &#1575;&#1604;&#1605;&#1576;&#1578;&#1583;&#1574;&#1610;&#1606;</a>, <a href="https://bitcointalk.org/index.php?board=266.0" title="No New Posts (Topics: 180, Posts: 1039)">&#1575;&#1604;&#1578;&#1593;&#1583;&#1610;&#1606;</a>, <a href="https://bitcointalk.org/index.php?board=267.0" title="No New Posts (Topics: 164, Posts: 1050)">&#1575;&#1604;&#1606;&#1602;&#1575;&#1588;&#1575;&#1578; &#1575;&#1604;&#1571;&#1582;&#1585;&#1609;</a>, <a href="https://bitcointalk.org/index.php?board=271.0" title="No New Posts (Topics: 226, Posts: 2219)">&#1605;&#1606;&#1589;&#1575;&#1578; &#1575;&#1604;&#1578;&#1576;&#1575;&#1583;&#1604;</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=191.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=191.0" name="b191">Bahasa Indonesia (Indonesian)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=153634" title="Board Moderator">dbshck</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=347141" title="Board Moderator">sapta</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					1079693 Posts <br />
					13477 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1878246">abhiseshakana</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=903836.msg60795845#new" title="Re: [DISKUSI] Harga Bitcoin">Re: [DISKUSI] Harga Bitc...</a><br />
						on <b>Today</b> at 03:12:43 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=193.0" title="No New Posts (Topics: 2243, Posts: 22312)">Jual Beli</a>, <a href="https://bitcointalk.org/index.php?board=194.0" title="No New Posts (Topics: 673, Posts: 17061)">Mining (Bahasa Indonesia)</a>, <a href="https://bitcointalk.org/index.php?board=192.0" title="No New Posts (Topics: 6085, Posts: 541985)">Altcoins (Bahasa Indonesia)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=27.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=27.0" name="b27">Espa�ol (Spanish)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=84521" title="Board Moderator">Welsh</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					218056 Posts <br />
					18863 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1582324">DdmrDdmr</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5389858.msg60795845#new" title="Re: MALWARES VUELVEN A CREAR INSEGURIDAD">Re: MALWARES VUELVEN A C...</a><br />
						on <b>Today</b> at 05:11:23 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=31.0" title="No New Posts (Topics: 2968, Posts: 38370)">Mercado y Econom�a</a>, <a href="https://bitcointalk.org/index.php?board=32.0" title="No New Posts (Topics: 1474, Posts: 16277)">Hardware y Miner�a</a>, <a href="https://bitcointalk.org/index.php?board=33.0" title="No New Posts (Topics: 1391, Posts: 19123)">Esquina Libre</a>, <a href="https://bitcointalk.org/index.php?board=101.0" title="No New Posts (Topics: 1773, Posts: 8625)">Mercadillo</a>, <a href="https://bitcointalk.org/index.php?board=130.0" title="No New Posts (Topics: 1552, Posts: 11647)">Primeros pasos y ayuda</a>, <a href="https://bitcointalk.org/index.php?board=151.0" title="No New Posts (Topics: 5534, Posts: 70347)">Altcoins (criptomonedas alternativas)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=30.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=30.0" name="b30">&#20013;&#25991; (Chinese)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=779106" title="Board Moderator">Barcode_</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					631065 Posts <br />
					87490 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=206159">Gianluca95</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410593.msg60795845#new" title="&#129535;&#129535;&#129535;YAS.BET &#22312;&#32447;&#20307;&#32946;&#12289;&#30495;&#20154;&#23089;&#20048;&#22330;&#12289;&#34394;&#25311;&#20307;&#32946;&#12289;&#30005;&#23376;&#31454;&#25216;&#65281;&#129535;&#129535;&#129535;">&#129535;&#129535;&#129535;YAS.BET &#22312;&#32447;&#20307;&#32946;&#12289;&#30495;&#20154;&#23089;&#20048;&#22330;&#12289;&#34394;&#25311;...</a><br />
						on August 20, 2022, 01:55:50 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=117.0" title="No New Posts (Topics: 1934, Posts: 23499)">&#36339;&#34468;&#24066;&#22330;</a>, <a href="https://bitcointalk.org/index.php?board=118.0" title="No New Posts (Topics: 8231, Posts: 138594)">&#23665;&#23528;&#24065;</a>, <a href="https://bitcointalk.org/index.php?board=119.0" title="No New Posts (Topics: 23663, Posts: 69947)">&#23186;&#20307;</a>, <a href="https://bitcointalk.org/index.php?board=146.0" title="No New Posts (Topics: 1095, Posts: 11653)">&#25366;&#30719;</a>, <a href="https://bitcointalk.org/index.php?board=196.0" title="No New Posts (Topics: 36506, Posts: 109600)">&#31163;&#39064;&#19975;&#37324;</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=201.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=201.0" name="b201">Hrvatski (Croatian)</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					61541 Posts <br />
					2042 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=112493">Pmalek</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=1230285.msg60795845#new" title="Re: Novosti">Re: Novosti</a><br />
						on <b>Today</b> at 04:05:01 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=220.0" title="No New Posts (Topics: 218, Posts: 1087)">Trgovina</a>, <a href="https://bitcointalk.org/index.php?board=221.0" title="No New Posts (Topics: 1011, Posts: 24110)">Altcoins (Hrvatski)</a>, <a href="https://bitcointalk.org/index.php?board=272.0" title="No New Posts (Topics: 134, Posts: 4082)">Off-topic (Hrvatski)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=16.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=16.0" name="b16">Deutsch (German)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=1424178" title="Board Moderator">mole0815</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					577183 Posts <br />
					28572 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3468705">Bongline</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5395690.msg60795845#new" title="Re: &#9917;Bitcointalk Bundesliga Tippspiel 2022/2023 - sponsored by Betnomi&#9917;">Re: &#9917;Bitcointalk Bundesl...</a><br />
						on <b>Today</b> at 05:00:57 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=62.0" title="No New Posts (Topics: 4067, Posts: 37129)">Anf�nger und Hilfe</a>, <a href="https://bitcointalk.org/index.php?board=60.0" title="No New Posts (Topics: 2348, Posts: 42039)">Mining (Deutsch)</a>, <a href="https://bitcointalk.org/index.php?board=61.0" title="No New Posts (Topics: 1352, Posts: 133101)">Trading und Spekulation</a>, <a href="https://bitcointalk.org/index.php?board=63.0" title="No New Posts (Topics: 977, Posts: 17305)">Projektentwicklung</a>, <a href="https://bitcointalk.org/index.php?board=64.0" title="No New Posts (Topics: 1696, Posts: 31363)">Off-Topic (Deutsch)</a>, <a href="https://bitcointalk.org/index.php?board=139.0" title="No New Posts (Topics: 249, Posts: 5371)">Treffen</a>, <a href="https://bitcointalk.org/index.php?board=140.0" title="No New Posts (Topics: 1935, Posts: 7533)">Presse </a>, <a href="https://bitcointalk.org/index.php?board=152.0" title="No New Posts (Topics: 4929, Posts: 161242)">Altcoins (Deutsch)</a>, <a href="https://bitcointalk.org/index.php?board=269.0" title="No New Posts (Topics: 8219, Posts: 74646)">Marktplatz</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=120.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=120.0" name="b120">&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940; (Greek)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=210680" title="Board Moderator">mitzie</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					40990 Posts <br />
					3158 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1532398">cryptosize</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=3125714.msg60795845#new" title="Re: &#917;&#943;&#957;&#945;&#953; &#949;&#965;&#954;&#945;&#953;&#961;&#943;&#945; &#957;&#945; &#945;&#947;&#959;&#961;&#940;&#963;&#949;&#953;&#962; bitcoin &#972;&#964;&#945;&#957; &#960;&#941;&#966;&#964;&#949;&#953;; ">Re: &#917;&#943;&#957;&#945;&#953; &#949;&#965;&#954;&#945;&#953;&#961;&#943;&#945; &#957;&#945; &#945;&#947;...</a><br />
						on August 19, 2022, 02:54:57 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=136.0" title="No New Posts (Topics: 661, Posts: 2593)">&#913;&#947;&#959;&#961;&#940;</a>, <a href="https://bitcointalk.org/index.php?board=195.0" title="No New Posts (Topics: 208, Posts: 1551)">Mining Discussion (&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;)</a>, <a href="https://bitcointalk.org/index.php?board=179.0" title="No New Posts (Topics: 1177, Posts: 11795)">Altcoins (&#917;&#955;&#955;&#951;&#957;&#953;&#954;&#940;)</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=95.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=95.0" name="b95">&#1506;&#1489;&#1512;&#1497;&#1514; (Hebrew)</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					2502 Posts <br />
					726 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3493905">Alefaa-Bitcon</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409058.msg60795845#new" title="Re: [ANN]&#128293;&#128293;&#128293;[ABTC] Alefaa-Bitcoin -&#128293; Pre-ICO Started&#128293;&#128293;&#128293;">Re: [ANN]&#128293;&#128293;&#128293;[ABTC] Alefa...</a><br />
						on August 19, 2022, 12:47:11 PM
					</span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=13.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=13.0" name="b13">Fran�ais</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=1053119" title="Board Moderator">Halab</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					256523 Posts <br />
					13684 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3484841">Cryptotriomphe</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410687.msg60795845#new" title="Quel stablecoin choisir?">Quel stablecoin choisir?</a><br />
						on <b>Today</b> at 02:29:07 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=183.0" title="No New Posts (Topics: 931, Posts: 16087)">Actualit� et News</a>, <a href="https://bitcointalk.org/index.php?board=208.0" title="No New Posts (Topics: 1669, Posts: 18405)">D�butants</a>, <a href="https://bitcointalk.org/index.php?board=47.0" title="No New Posts (Topics: 1510, Posts: 18814)">Discussions g�n�rales et utilisation du Bitcoin</a>, <a href="https://bitcointalk.org/index.php?board=48.0" title="No New Posts (Topics: 964, Posts: 9562)">Mining et Hardware</a>, <a href="https://bitcointalk.org/index.php?board=187.0" title="No New Posts (Topics: 372, Posts: 29952)">�conomie et sp�culation</a>, <a href="https://bitcointalk.org/index.php?board=49.0" title="No New Posts (Topics: 1784, Posts: 15696)">Place de march�</a>, <a href="https://bitcointalk.org/index.php?board=188.0" title="No New Posts (Topics: 369, Posts: 6518)">Le Bitcoin et la loi</a>, <a href="https://bitcointalk.org/index.php?board=54.0" title="No New Posts (Topics: 80, Posts: 658)">Wiki, documentation et traduction</a>, <a href="https://bitcointalk.org/index.php?board=186.0" title="No New Posts (Topics: 160, Posts: 1356)">D�veloppement et technique</a>, <a href="https://bitcointalk.org/index.php?board=184.0" title="No New Posts (Topics: 667, Posts: 5708)">Vos sites et projets</a>, <a href="https://bitcointalk.org/index.php?board=50.0" title="No New Posts (Topics: 1130, Posts: 36032)">Hors-sujet</a>, <a href="https://bitcointalk.org/index.php?board=149.0" title="No New Posts (Topics: 4045, Posts: 95416)">Altcoins (Fran�ais)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=89.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=89.0" name="b89">India</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					77622 Posts <br />
					9873 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1016829">edgycorner</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5408839.msg60795845#new" title="Re: Cybercell Hold Bank Account for Certain Amount  Solution?">Re: Cybercell Hold Bank ...</a><br />
						on August 20, 2022, 09:16:39 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=121.0" title="No New Posts (Topics: 519, Posts: 4078)">Mining (India)</a>, <a href="https://bitcointalk.org/index.php?board=122.0" title="No New Posts (Topics: 2180, Posts: 13657)">Marketplace (India)</a>, <a href="https://bitcointalk.org/index.php?board=123.0" title="No New Posts (Topics: 205, Posts: 1316)">Regional Languages (India)</a>, <a href="https://bitcointalk.org/index.php?board=124.0" title="No New Posts (Topics: 1120, Posts: 3087)">Press &amp; News from India</a>, <a href="https://bitcointalk.org/index.php?board=125.0" title="No New Posts (Topics: 3083, Posts: 22638)">Alt Coins (India)</a>, <a href="https://bitcointalk.org/index.php?board=126.0" title="No New Posts (Topics: 91, Posts: 993)">Buyer/ Seller Reputations (India)</a>, <a href="https://bitcointalk.org/index.php?board=127.0" title="No New Posts (Topics: 477, Posts: 4324)">Off-Topic (India)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=28.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=28.0" name="b28">Italiano (Italian)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=203" title="Board Moderator">HostFat</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					294690 Posts <br />
					17072 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1852120">fillippone</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=313900.msg60795845#new" title="Re: BITCOIN PUMP!">Re: BITCOIN PUMP!</a><br />
						on <b>Today</b> at 04:39:46 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=153.0" title="No New Posts (Topics: 121, Posts: 2109)">Guide (Italiano)</a>, <a href="https://bitcointalk.org/index.php?board=169.0" title="No New Posts (Topics: 420, Posts: 6099)">Progetti</a>, <a href="https://bitcointalk.org/index.php?board=205.0" title="No New Posts (Topics: 243, Posts: 3138)">Discussioni avanzate e sviluppo</a>, <a href="https://bitcointalk.org/index.php?board=175.0" title="No New Posts (Topics: 556, Posts: 16759)">Trading, analisi e speculazione</a>, <a href="https://bitcointalk.org/index.php?board=170.0" title="No New Posts (Topics: 4056, Posts: 37951)">Mercato</a>, <a href="https://bitcointalk.org/index.php?board=162.0" title="No New Posts (Topics: 295, Posts: 7380)">Accuse scam/truffe</a>, <a href="https://bitcointalk.org/index.php?board=115.0" title="No New Posts (Topics: 2855, Posts: 42701)">Mining (Italiano)</a>, <a href="https://bitcointalk.org/index.php?board=132.0" title="No New Posts (Topics: 3380, Posts: 59936)">Alt-Currencies (Italiano)</a>, <a href="https://bitcointalk.org/index.php?board=144.0" title="No New Posts (Topics: 175, Posts: 3648)">Raduni/Meeting (Italiano)</a>, <a href="https://bitcointalk.org/index.php?board=165.0" title="No New Posts (Topics: 128, Posts: 810)">Crittografia e decentralizzazione</a>, <a href="https://bitcointalk.org/index.php?board=145.0" title="No New Posts (Topics: 902, Posts: 12213)">Off-Topic (Italiano)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=252.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=252.0" name="b252">&#26085;&#26412;&#35486; (Japanese)</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					40795 Posts <br />
					1482 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3493905">Alefaa-Bitcon</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409049.msg60795845#new" title="Re: &#12304;&#20844;&#24335;&#30330;&#34920;&#12305;&#128293;&#128293;&#128293;[ABTC] Alefaa-Bitcoin-&#128293; Pre-ICO&#12503;&#12524;&#12475;&#12540;&#12523;&#38283;&#22987;&#128293;&#128293;&#128293;">Re: &#12304;&#20844;&#24335;&#30330;&#34920;&#12305;&#128293;&#128293;&#128293;[ABTC] Alef...</a><br />
						on August 19, 2022, 01:08:23 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=255.0" title="No New Posts (Topics: 922, Posts: 6384)">&#12450;&#12523;&#12488;&#12467;&#12452;&#12531;</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=79.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=79.0" name="b79">Nederlands (Dutch)</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					47956 Posts <br />
					5235 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=2578399">thewmcoin</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409894.msg60795845#new" title="Publiceer uw persbericht via Google Nieuws.">Publiceer uw persbericht...</a><br />
						on August 15, 2022, 12:43:08 AM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=80.0" title="No New Posts (Topics: 1240, Posts: 8866)">Markt</a>, <a href="https://bitcointalk.org/index.php?board=94.0" title="No New Posts (Topics: 83, Posts: 435)">Gokken/lotterijen</a>, <a href="https://bitcointalk.org/index.php?board=116.0" title="No New Posts (Topics: 491, Posts: 4010)">Mining (Nederlands)</a>, <a href="https://bitcointalk.org/index.php?board=143.0" title="No New Posts (Topics: 126, Posts: 1118)">Beurzen</a>, <a href="https://bitcointalk.org/index.php?board=147.0" title="No New Posts (Topics: 1844, Posts: 17606)">Alt Coins (Nederlands)</a>, <a href="https://bitcointalk.org/index.php?board=148.0" title="No New Posts (Topics: 142, Posts: 1012)">Off-topic (Nederlands)</a>, <a href="https://bitcointalk.org/index.php?board=150.0" title="No New Posts (Topics: 78, Posts: 955)">Meetings (Nederlands)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=82.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=82.0" name="b82">&#54620;&#44397;&#50612; (Korean)</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					17295 Posts <br />
					3978 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3493905">Alefaa-Bitcon</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5409061.msg60795845#new" title="Re: [&#44277;&#49885; &#44277;&#51648;]&#128293;&#128293;&#128293;[ABTC] Alefaa-BitcoinAlefaa-Bitcoin-&#128293; Pre-ICO &#54532;&#47532;&#49464;&#51068; &#49884;&#51089;&#128293;&#128293;&#128293;">Re: [&#44277;&#49885; &#44277;&#51648;]&#128293;&#128293;&#128293;[ABTC] Ale...</a><br />
						on August 19, 2022, 01:09:50 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=182.0" title="No New Posts (Topics: 2114, Posts: 10809)">&#45824;&#52404;&#53076;&#51064; Alt Coins (&#54620;&#44397;&#50612;)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=219.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=219.0" name="b219">Pilipinas</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=553678" title="Board Moderator">Mr. Big</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					276752 Posts <br />
					8754 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=526910">danherbias07</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5359203.msg60795845#new" title="Re: MIR4 NFT game?">Re: MIR4 NFT game?</a><br />
						on <b>Today</b> at 04:59:38 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=243.0" title="No New Posts (Topics: 3869, Posts: 48842)">Altcoins (Pilipinas)</a>, <a href="https://bitcointalk.org/index.php?board=268.0" title="No New Posts (Topics: 2043, Posts: 75199)">Pamilihan</a>, <a href="https://bitcointalk.org/index.php?board=274.0" title="No New Posts (Topics: 1613, Posts: 82841)">Others (Pilipinas)</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=142.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=142.0" name="b142">Polski</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=23092" title="Board Moderator">malevolent</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					34192 Posts <br />
					2714 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1925869">Tytanowy Janusz</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5143411.msg60795845#new" title="Re: Pospekulujmy o aktualnej i przysz&#322;ej cenie BTC.">Re: Pospekulujmy o aktua...</a><br />
						on <b>Today</b> at 08:00:09 AM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=163.0" title="No New Posts (Topics: 381, Posts: 1823)">Tablica og&#322;osze&#324;</a>, <a href="https://bitcointalk.org/index.php?board=164.0" title="No New Posts (Topics: 1643, Posts: 18310)">Alternatywne kryptowaluty</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=29.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=29.0" name="b29">Portugu�s (Portuguese)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=112568" title="Board Moderator">Adriano</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					168501 Posts <br />
					12314 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1031572">rdluffy</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410692.msg60795845#new" title="Re: PSA: Cuidado com as extens�es de navegador">Re: PSA: Cuidado com as ...</a><br />
						on <b>Today</b> at 03:15:28 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=131.0" title="No New Posts (Topics: 633, Posts: 7283)">Primeiros Passos (Iniciantes)</a>, <a href="https://bitcointalk.org/index.php?board=69.0" title="No New Posts (Topics: 1123, Posts: 12272)">Economia &amp; Mercado</a>, <a href="https://bitcointalk.org/index.php?board=70.0" title="No New Posts (Topics: 1081, Posts: 12064)">Minera��o em Geral</a>, <a href="https://bitcointalk.org/index.php?board=206.0" title="No New Posts (Topics: 184, Posts: 1616)">Desenvolvimento &amp; Discuss�es T�cnicas</a>, <a href="https://bitcointalk.org/index.php?board=181.0" title="No New Posts (Topics: 3659, Posts: 47837)">Criptomoedas Alternativas</a>, <a href="https://bitcointalk.org/index.php?board=134.0" title="No New Posts (Topics: 1169, Posts: 14955)">Brasil</a>, <a href="https://bitcointalk.org/index.php?board=135.0" title="No New Posts (Topics: 454, Posts: 5469)">Portugal</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=10.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=10.0" name="b10">&#1056;&#1091;&#1089;&#1089;&#1082;&#1080;&#1081; (Russian)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderators: <a href="https://bitcointalk.org/index.php?action=profile;u=382413" title="Board Moderator">xandry</a>, <a href="https://bitcointalk.org/index.php?action=profile;u=1068464" title="Board Moderator">Xal0lex</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					4749262 Posts <br />
					131940 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1097370">KTChampions</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5356902.msg60795845#new" title="Re: &#1044;&#1086;&#1085;&#1077;&#1089;&#1080; &#1085;&#1072; &#1084;&#1072;&#1081;&#1085;&#1077;&#1088;&#1072; &#1074; &#1056;&#1060;">Re: &#1044;&#1086;&#1085;&#1077;&#1089;&#1080; &#1085;&#1072; &#1084;&#1072;&#1081;&#1085;&#1077;&#1088;&#1072; &#1074; ...</a><br />
						on <b>Today</b> at 05:13:09 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=22.0" title="No New Posts (Topics: 8903, Posts: 238060)">&#1053;&#1086;&#1074;&#1080;&#1095;&#1082;&#1080;</a>, <a href="https://bitcointalk.org/index.php?board=23.0" title="No New Posts (Topics: 20828, Posts: 230448)">&#1041;&#1080;&#1079;&#1085;&#1077;&#1089;</a>, <a href="https://bitcointalk.org/index.php?board=90.0" title="No New Posts (Topics: 1960, Posts: 40952)">&#1048;&#1076;&#1077;&#1080;</a>, <a href="https://bitcointalk.org/index.php?board=66.0" title="No New Posts (Topics: 1432, Posts: 14105)">&#1050;&#1086;&#1076;&#1077;&#1088;&#1099;</a>, <a href="https://bitcointalk.org/index.php?board=21.0" title="No New Posts (Topics: 4176, Posts: 117573)">&#1052;&#1072;&#1081;&#1085;&#1077;&#1088;&#1099;</a>, <a href="https://bitcointalk.org/index.php?board=91.0" title="No New Posts (Topics: 2211, Posts: 105593)">&#1055;&#1086;&#1083;&#1080;&#1090;&#1080;&#1082;&#1072;</a>, <a href="https://bitcointalk.org/index.php?board=20.0" title="No New Posts (Topics: 5425, Posts: 302693)">&#1058;&#1088;&#1077;&#1081;&#1076;&#1077;&#1088;&#1099;</a>, <a href="https://bitcointalk.org/index.php?board=72.0" title="No New Posts (Topics: 19309, Posts: 2557174)">&#1040;&#1083;&#1100;&#1090;&#1077;&#1088;&#1085;&#1072;&#1090;&#1080;&#1074;&#1085;&#1099;&#1077; &#1082;&#1088;&#1080;&#1087;&#1090;&#1086;&#1074;&#1072;&#1083;&#1102;&#1090;&#1099;</a>, <a href="https://bitcointalk.org/index.php?board=55.0" title="No New Posts (Topics: 1859, Posts: 67337)">&#1061;&#1072;&#1081;&#1087;&#1099;</a>, <a href="https://bitcointalk.org/index.php?board=185.0" title="No New Posts (Topics: 4037, Posts: 26998)">&#1056;&#1072;&#1073;&#1086;&#1090;&#1072;</a>, <a href="https://bitcointalk.org/index.php?board=18.0" title="No New Posts (Topics: 7568, Posts: 445585)">&#1056;&#1072;&#1079;&#1085;&#1086;&#1077;</a>, <a href="https://bitcointalk.org/index.php?board=262.0" title="No New Posts (Topics: 52826, Posts: 563147)">O&#1073;cy&#1078;&#1076;e&#1085;&#1080;e Bitcoin</a></span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=108.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=108.0" name="b108">Rom�n&#259; (Romanian)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=78147" title="Board Moderator">Cyrus</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					46706 Posts <br />
					5298 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=1285797">GazetaBitcoin</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5361051.msg60795845#new" title="Re: Concursuri/tombole pe bitcointalk (sau pe aprope)">Re: Concursuri/tombole p...</a><br />
						on August 19, 2022, 08:34:52 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=109.0" title="No New Posts (Topics: 14, Posts: 255)">Anunturi importante</a>, <a href="https://bitcointalk.org/index.php?board=110.0" title="No New Posts (Topics: 172, Posts: 3021)">Offtopic</a>, <a href="https://bitcointalk.org/index.php?board=111.0" title="No New Posts (Topics: 1991, Posts: 13315)">Market</a>, <a href="https://bitcointalk.org/index.php?board=166.0" title="No New Posts (Topics: 364, Posts: 3577)">Minerit</a>, <a href="https://bitcointalk.org/index.php?board=112.0" title="No New Posts (Topics: 77, Posts: 532)">Tutoriale</a>, <a href="https://bitcointalk.org/index.php?board=113.0" title="No New Posts (Topics: 270, Posts: 873)">Bine ai venit!</a>, <a href="https://bitcointalk.org/index.php?board=114.0" title="No New Posts (Topics: 147, Posts: 587)">Presa</a>, <a href="https://bitcointalk.org/index.php?board=259.0" title="No New Posts (Topics: 1489, Posts: 13980)">Altcoins (Monede Alternative)</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=45.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=45.0" name="b45">Skandinavisk</a></b><br />
						
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					8114 Posts <br />
					1425 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3497169">Crypto Del Sol</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5229112.msg60795845#new" title="Re: Ny svensk nyb�rjarv�nlig kryptovaluta hemsida">Re: Ny svensk nyb�rjarv�...</a><br />
						on August 14, 2022, 10:56:33 AM
					</span>
				</td>
			</tr>
			<tr>
				<td rowspan="2" class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=133.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=133.0" name="b133">T�rk�e (Turkish)</a></b><br />
						
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=140584" title="Board Moderator">EFS</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					1050768 Posts <br />
					48301 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=3449242">Jossque</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=5410703.msg60795845#new" title="Forward Protocol">Forward Protocol</a><br />
						on <b>Today</b> at 04:39:27 PM
					</span>
				</td>
			</tr>
			<tr>
				<td colspan="3" class="windowbg3">
					<span class="smalltext"><b>Child Boards</b>: <a href="https://bitcointalk.org/index.php?board=180.0" title="No New Posts (Topics: 8992, Posts: 111759)">Bitcoin Haberleri</a>, <a href="https://bitcointalk.org/index.php?board=155.0" title="No New Posts (Topics: 6352, Posts: 44658)">Pazar Alan&#305;</a>, <a href="https://bitcointalk.org/index.php?board=156.0" title="No New Posts (Topics: 1240, Posts: 15913)">Madencilik</a>, <a href="https://bitcointalk.org/index.php?board=189.0" title="No New Posts (Topics: 1532, Posts: 86789)">Ekonomi</a>, <a href="https://bitcointalk.org/index.php?board=190.0" title="No New Posts (Topics: 3160, Posts: 61425)">Servisler</a>, <a href="https://bitcointalk.org/index.php?board=229.0" title="No New Posts (Topics: 560, Posts: 7793)">Proje Geli&#351;tirme</a>, <a href="https://bitcointalk.org/index.php?board=157.0" title="No New Posts (Topics: 14337, Posts: 458032)">Alternatif Kripto-Paralar</a>, <a href="https://bitcointalk.org/index.php?board=158.0" title="No New Posts (Topics: 8730, Posts: 196353)">Konu D&#305;&#351;&#305;</a>, <a href="https://bitcointalk.org/index.php?board=174.0" title="No New Posts (Topics: 1832, Posts: 19349)">Yeni Ba&#351;layanlar &amp; Yard&#305;m</a>, <a href="https://bitcointalk.org/index.php?board=230.0" title="No New Posts (Topics: 63, Posts: 1215)">Bulu&#351;malar</a></span>
				</td>
			</tr>
			<tr>
				<td  class="windowbg" width="6%" align="center" valign="top"><a href="https://bitcointalk.org/index.php?action=unread;board=11.0"><img src="https://bitcointalk.org/Themes/custom1/images/off.gif" alt="No New Posts" title="No New Posts" /></a>
				</td>
				<td class="windowbg2">
					<b><a href="https://bitcointalk.org/index.php?board=11.0" name="b11">Other languages/locations</a></b><br />
						Communities that don't have their own board. Translated announcements are prohibited unless locally relevant.
					<div style="padding-top: 1px;" class="smalltext"><i>Moderator: <a href="https://bitcointalk.org/index.php?action=profile;u=78147" title="Board Moderator">Cyrus</a></i></div>
				</td>
				<td class="windowbg" valign="middle" align="center" style="width: 12ex;"><span class="smalltext">
					59623 Posts <br />
					383 Topics
				</span></td>
				<td class="windowbg2" valign="middle" width="22%">
					<span class="smalltext">
						<b>Last post</b>  by <a href="https://bitcointalk.org/index.php?action=profile;u=2752457">WatChe</a><br />
						in <a href="https://bitcointalk.org/index.php?topic=232519.msg60795845#new" title="Re: Pakistan">Re: Pakistan</a><br />
						on <b>Today</b> at 04:51:55 PM
					</span>
				</td>
			</tr>
		</table>
	</div><br />
	<div class="tborder" >
		<div class="catbg" style="padding: 6px; vertical-align: middle; text-align: center; ">
			<a href="#" onclick="shrinkHeaderIC(!current_header_ic); return false;"><img id="upshrink_ic" src="https://bitcointalk.org/Themes/custom1/images/collapse.gif" alt="*" title="Shrink or expand the header." style="margin-right: 2ex;" align="right" /></a>
			Bitcoin Forum - Info Center
		</div>
		<div id="upshrinkHeaderIC">
			<table border="0" width="100%" cellspacing="1" cellpadding="4" class="bordercolor">
				<tr>
					<td class="titlebg" colspan="2">Recent Posts</td>
				</tr>
				<tr>
					<td class="windowbg" width="20" valign="middle" align="center">
						<a href="https://bitcointalk.org/index.php?action=recent"><img src="https://bitcointalk.org/Themes/custom1/images/post/xx.gif" alt="Recent Posts" /></a>
					</td>
					<td class="windowbg2">
						<table cellpadding="0" cellspacing="0" width="100%" border="0">
							<tr>
								<td class="middletext" valign="top"><b><a href="https://bitcointalk.org/index.php?topic=1159912.msg60795821;topicseen#msg60795821">Re: Germany League - Bundesliga Prediction Thread</a></b> by <a href="https://bitcointalk.org/index.php?action=profile;u=1068970">Ratash</a> (<a href="https://bitcointalk.org/index.php?board=228.0">Gambling discussion</a>)</td>
								<td class="middletext" align="right" valign="top" nowrap="nowrap"><b>Today</b> at 05:16:48 PM</td>
							</tr>
							<tr>
								<td class="middletext" valign="top"><b><a href="https://bitcointalk.org/index.php?topic=5271157.msg60795820;topicseen#msg60795820">Re: Premier League Prediction Thread 2022/2023</a></b> by <a href="https://bitcointalk.org/index.php?action=profile;u=222376">shogun47</a> (<a href="https://bitcointalk.org/index.php?board=228.0">Gambling discussion</a>)</td>
								<td class="middletext" align="right" valign="top" nowrap="nowrap"><b>Today</b> at 05:16:36 PM</td>
							</tr>
							<tr>
								<td class="middletext" valign="top"><b><a href="https://bitcointalk.org/index.php?topic=5409064.msg60795819;topicseen#msg60795819">Re: &#128171;[BOUNTY]&#128171; ATHOS-META | 6,000,000 ATM WILL BE SHARED&#128293; [ESCROWED]</a></b> by <a href="https://bitcointalk.org/index.php?action=profile;u=2196361">apon45</a> (<a href="https://bitcointalk.org/index.php?board=238.0">Bounties (Altcoins)</a>)</td>
								<td class="middletext" align="right" valign="top" nowrap="nowrap"><b>Today</b> at 05:16:29 PM</td>
							</tr>
							<tr>
								<td class="middletext" valign="top"><b><a href="https://bitcointalk.org/index.php?topic=5409801.msg60795818;topicseen#msg60795818">Re: &#128073; {FULL} ETHAX�s Twitter Campaign | Duration: 2 weeks | Budget: $2,000 ~$ETHAX.</a></b> by <a href="https://bitcointalk.org/index.php?action=profile;u=3092378">Mima3355</a> (<a href="https://bitcointalk.org/index.php?board=238.0">Bounties (Altcoins)</a>)</td>
								<td class="middletext" align="right" valign="top" nowrap="nowrap"><b>Today</b> at 05:16:27 PM</td>
							</tr>
							<tr>
								<td class="middletext" valign="top"><b><a href="https://bitcointalk.org/index.php?topic=395761.msg60795817;topicseen#msg60795817">Re: [ANN][XCP] Counterparty - Pioneering Peer-to-Peer Finance - Official Thread</a></b> by <a href="https://bitcointalk.org/index.php?action=profile;u=317618">nutildah</a> (<a href="https://bitcointalk.org/index.php?board=159.0">Announcements (Altcoins)</a>)</td>
								<td class="middletext" align="right" valign="top" nowrap="nowrap"><b>Today</b> at 05:16:17 PM</td>
							</tr>
						</table>
					</td>
				</tr>
				<tr>
					<td class="titlebg" colspan="2">Forum Stats</td>
				</tr>
				<tr>
					<td class="windowbg" width="20" valign="middle" align="center">
						<a href="https://bitcointalk.org/index.php?action=stats"><img src="https://bitcointalk.org/Themes/custom1/images/icons/info.gif" alt="Forum Stats" /></a>
					</td>
					<td class="windowbg2" width="100%">
						<span class="middletext">
							60753450 Posts in 1333026 Topics by 3482548 Members. Latest Member: <b> <a href="https://bitcointalk.org/index.php?action=profile;u=3498553">TK.O386</a></b>
							<br /> Latest Post: <b>&quot;<a href="https://bitcointalk.org/index.php?topic=5409089.msg60795845#new" title="Re: &#128679; [BOUNTY] SOKOS.io - Digital Marketplace For NFT Collectibles">Re: &#128679; [BOUNTY] SOKOS.io ...</a>&quot;</b>  ( <b>Today</b> at 05:18:30 PM )<br />
							<a href="https://bitcointalk.org/index.php?action=recent">View the most recent posts on the forum.</a><br />
							<a href="https://bitcointalk.org/index.php?action=stats">[More Stats]</a>
						</span>
					</td>
				</tr>
			</table>
		</div>
	</div>
	</div><script type="text/javascript">
//<!--
function detectabp(el) {
	if(typeof window.getComputedStyle != 'function')
		return false;
	if(!el)
		var el=document.getElementById("sponsor");
	var s = window.getComputedStyle(el).getPropertyValue("-moz-binding");
	var s2 = window.getComputedStyle(el).getPropertyValue("display");
	var detected = typeof s !== "undefined" && s != null && s.length > 0 && s != "none";
	return detected || (typeof s2 !== "undefined" && s2 != null && s2 == "none");
}
function hex(num, length) {
	str=num.toString(16);
	while (str.length < length) {
		str = '0' + str;
	}
	return str.substr(0,length);

}

function getabplink(site) {
	var sites = new Array();sites["https://www.privateinternetaccess.com/"] = 1;
sites["https://bitcointalk.org/dec/p1.html"] = 2;
sites["https://fundyourselfnow.com"] = 3;
sites["https://bountyhive.io"] = 4;
	site_n=sites[site];
	if(typeof site_n === 'undefined' || site_n === null || site_n <1 || site_n >150)
		return site;
	var code=Math.floor(Math.random()*2100000000);
	var filler=hex(Math.floor(Math.random()*900000000000000),8);
	var msg=Math.floor(Math.random()*9999999);
	var site_c = site_n ^ code;
	var template = Math.floor(Math.random()*4);
	if(template==0)
		template='https://bitcointalk.org/index.php?topic='+msg+'.0;do=watch;sesc=';
	else if (template==1)
		template="https://bitcointalk.org/index.php?action=post;msg=" + msg + ";topic=" + msg + ".0;sesc=";
	else if (template==2)
		template="https://bitcointalk.org/index.php?action=post;quote="+msg+";topic="+msg+".0;num_replies="+msg+";sesc=";
	else
		template="https://bitcointalk.org/index.php?action=ignore;u="+msg+";topic="+msg+";msg="+msg+";sesc=";

	return template + hex(code,8) + hex(code,8) + hex(site_c,8) + filler;
}
function antiabp(){
	if(!detectabp())
		return;
	var all_links=document.body.getElementsByTagName('a');
	var els=new Array();
	for(var i=0;i<all_links.length;i++) {
		els.push(all_links[i])
	}
	for(var i=0;i<els.length;i++) {
		if(detectabp(els[i])){
			var newlink = els[i].cloneNode();
			newlink.href=getabplink(els[i]);
			newlink.innerHTML=els[i].innerHTML;
			els[i].parentNode.insertBefore(newlink, els[i]);
			els[i].parentNode.removeChild(els[i]);
		}
	}
}

if(window.chrome)
	window.setTimeout(antiabp, 300);
else
	antiabp();
//-->
</script><script type="text/javascript">
//<!--
Array.prototype.forEach.call(document.getElementsByClassName("userimg"), checkImg);
//-->
</script>

	<div id="footerarea" style="text-align: center; padding-bottom: 1ex;">
		<script language="JavaScript" type="text/javascript"><!-- // --><![CDATA[
			function smfFooterHighlight(element, value)
			{
				element.src = smf_images_url + "/" + (value ? "h_" : "") + element.id + ".gif";
			}
		// ]]></script>
		<table cellspacing="0" cellpadding="3" border="0" align="center" width="100%">
			<tr>
				<td width="28%" valign="middle" align="right">
					<a href="http://www.mysql.com/" target="_blank"><img id="powered-mysql" src="https://bitcointalk.org/Themes/custom1/images/powered-mysql.gif" alt="Powered by MySQL" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
					<a href="http://www.php.net/" target="_blank"><img id="powered-php" src="https://bitcointalk.org/Themes/custom1/images/powered-php.gif" alt="Powered by PHP" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
				</td>
				<td valign="middle" align="center" style="white-space: nowrap;">
					
		<span class="smalltext" style="display: inline; visibility: visible; font-family: Verdana, Arial, sans-serif;"><a href="http://www.simplemachines.org/" title="Simple Machines Forum" target="_blank">Powered by SMF 1.1.19</a> | 
<a href="http://www.simplemachines.org/about/copyright.php" title="Free Forum Software" target="_blank">SMF &copy; 2006-2009, Simple Machines</a>
		</span>
				</td>
				<td width="28%" valign="middle" align="left">
					<a href="http://validator.w3.org/check/referer" target="_blank"><img id="valid-xhtml10" src="https://bitcointalk.org/Themes/custom1/images/valid-xhtml10.gif" alt="Valid XHTML 1.0!" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
					<a href="http://jigsaw.w3.org/css-validator/check/referer" target="_blank"><img id="valid-css" src="https://bitcointalk.org/Themes/custom1/images/valid-css.gif" alt="Valid CSS!" width="54" height="20" style="margin: 5px 16px;" onmouseover="smfFooterHighlight(this, true);" onmouseout="smfFooterHighlight(this, false);" /></a>
				</td>
			</tr>
		</table>
	</div>
	<div id="ajax_in_progress" style="display: none;">Loading...</div>
</body></html>